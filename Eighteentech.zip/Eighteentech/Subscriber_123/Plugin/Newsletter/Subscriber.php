<?php

namespace Eighteentech\Subscriber\Plugin\Newsletter;

use Magento\Framework\App\Request\Http;

class Subscriber {
  protected $request;

  public function __construct(
    Http $request
  ) {
    $this->request = $request;
  }

  public function aroundSubscribe($subject, \Closure $proceed, $email) {
    $result = $proceed($email);
    if ($this->request->isPost() && $this->request->getPost('custom_name')) {
      $custom_name = $this->request->getPost('custom_name');
      

      $subject->setCustomName($custom_name);      

      try {
        $subject->save();
      }catch (\Exception $e) {
        throw new \Exception($e->getMessage());
      }
    }

    return $result;
  }
}