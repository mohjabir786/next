define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'clubpayment',
                component: 'Eighteentech_Clubpayment/js/view/payment/method-renderer/clubpayment'
            }
        );
        return Component.extend({});
    }
);
