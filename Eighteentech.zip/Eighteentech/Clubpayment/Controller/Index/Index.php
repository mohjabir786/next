<?php
namespace Eighteentech\Clubpayment\Controller\Index;
use Magento\Framework\Controller\ResultFactory;
class Index extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_scopeConfig;
	protected $cart;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Magento\Checkout\Model\Cart $cart
		)
		{
			$this->_scopeConfig = $scopeConfig;
			$this->_pageFactory = $pageFactory;
			$this->cart = $cart;
			return parent::__construct($context);
		}
		
	public function  execute(){
		echo 'hello club form';
		exit;
	}
}
