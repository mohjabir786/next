var config = {
    map: {
        '*' : {
            'owlcarousel' : 'Eighteentech_Instagram/js/owl.carousel',
            'owlcarouselmin' : 'Eighteentech_Instagram/js/owl.carousel.min',
            'instafeedmin' : 'Eighteentech_Instagram/js/instafeed.min'
        }
    },    
    shim: {
        'Eighteentech_Instagram/js/owl.carousel': {
            deps: ['jquery']
        },
        'Eighteentech_Instagram/js/owl.carousel.min': {
            deps: ['jquery']
        },
        'instafeedmin':{
			deps: ['jquery']
		}
    }
};
