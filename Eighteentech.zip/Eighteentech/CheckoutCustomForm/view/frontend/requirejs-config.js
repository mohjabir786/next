var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/view/shipping': {
                'Eighteentech_CheckoutCustomForm/js/view/shipping-mixin': true
            }
        }
    }
};
