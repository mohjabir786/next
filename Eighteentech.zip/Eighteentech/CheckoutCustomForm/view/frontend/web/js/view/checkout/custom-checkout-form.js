/*global define*/
define([
    'knockout',
    'jquery',
    'mage/url',
    'Magento_Ui/js/form/form',
    'Magento_Customer/js/model/customer',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/url-builder',
    'Magento_Checkout/js/model/error-processor',
    'Magento_Checkout/js/model/cart/cache',
    'Eighteentech_CheckoutCustomForm/js/model/checkout/custom-checkout-form'
], function(ko, $, urlFormatter, Component, customer, quote, urlBuilder, errorProcessor, cartCache, formData) {
    'use strict';

    return Component.extend({
        customFields: ko.observable(null),
        formData: formData.customFieldsData,

        /**
         * Initialize component
         *
         * @returns {exports}
         */
        initialize: function () {
            var self = this;
            this._super();
            formData = this.source.get('customCheckoutForm');
            var formDataCached = cartCache.get('custom-form');
            if (formDataCached) {
                formData = this.source.set('customCheckoutForm', formDataCached);
            }

            this.customFields.subscribe(function(change){
                self.formData(change);
            });

            return this;
        },

        /**
         * Trigger save method if form is change
         */
        onFormChange: function () {
            this.saveCustomFields();
        },
        
        checkClubMember: function(data,member){
			//alert('form-id'+data);
			if(data=='1'){
				$('.club-id-box').show();
			}else
			   $('.club-id-box').hide();
			return true;	
		},    
		
		
		checkGiftwrap: function(data,event){
			//alert('gift- wrap-id'+data);
			if(data=='1')
				$('.giftwrap-id-box').show();
			else
			   $('.giftwrap-id-box').hide();
			return true;   
		},
		
		checkFormValidation : function(){
			var formData = this.source.get('customCheckoutForm');
			var alreadyMember = $('input[name=checkout_already_member]:checked').val();
			//alert(alreadyMember);
			return false;
		},


        /**
         * Form submit handler
         */
        saveCustomFields: function() {
            //this.source.set('params.invalid', false);
            //this.source.trigger('customCheckoutForm.data.validate');
            /*this.checkFormValidation();           
            if (!this.source.get('params.invalid')) {*/                                   
            var checkout_already_member = $('input[name=checkout_already_member]:checked').val();
            var checkout_giftwrap = $('input[name=checkout_giftwrap]:checked').val();
            var checkout_club_id = $('#checkout_club_id').val();
            var checkout_giftwrap_message = $('#checkout_giftwrap_message').val();
            if(checkout_already_member=='1' && checkout_club_id==''){
				//alert('Please enter club id.');
			}
                var formData = {checkout_already_member:checkout_already_member,checkout_giftwrap:checkout_giftwrap,
					           checkout_club_id:checkout_club_id,checkout_giftwrap_message:checkout_giftwrap_message};//this.source.get('customCheckoutForm');
                var quoteId = quote.getQuoteId();
                var isCustomer = customer.isLoggedIn();
                var url;

                if (isCustomer) {
                    url = urlBuilder.createUrl('/carts/mine/set-club-giftwrap-fields', {});
                } else {
                    url = urlBuilder.createUrl('/guest-carts/:cartId/set-club-giftwrap-field', {cartId: quoteId});
                }

                var payload = {
                    cartId: quoteId,
                    customFields: formData
                };
                var result = true;
                $.ajax({
                    url: urlFormatter.build(url),
                    data: JSON.stringify(payload),
                    global: false,
                    contentType: 'application/json',
                    type: 'PUT',
                    async: true
                }).done(
                    function (response) {
                        cartCache.set('custom-form', formData);
                        result = true;
                    }
                ).fail(
                    function (response) {
                        result = false;
                        errorProcessor.process(response);
                    }
                );

                return result;
            //}
        }
    });
});
