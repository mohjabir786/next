define(
    [
        'ko',
    ],
    function(ko) {
        'use strict';
        return{
            customFieldsData: ko.observable(null)
        }
    }
);