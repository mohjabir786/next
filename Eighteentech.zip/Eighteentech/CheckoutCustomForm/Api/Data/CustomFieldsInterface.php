<?php

namespace Eighteentech\CheckoutCustomForm\Api\Data;

/**
 * Interface CustomFieldsInterface
 *
 * @category Api/Data/Interface
 * @package  Eighteentech\CheckoutCustomForm\Api\Data
 */
interface CustomFieldsInterface
{
    const CHECKOUT_ALREADY_MEMBER = 'checkout_already_member';
    const CHECKOUT_CLUB_ID = 'checkout_club_id';
    const CHECKOUT_GIFTWRAP = 'checkout_giftwrap';
    const CHECKOUT_GIFTWRAP_MESSAGE = 'checkout_giftwrap_message';

    /**
     * Get checkout already member
     *
     * @return string|null
     */
    public function getCheckoutAlreadyMember();

    /**
     * Get checkout club id
     *
     * @return string|null
     */
    public function getCheckoutClubId();

    /**
     * Get checkout giftwrap
     *
     * @return string|null
     */
    public function getCheckoutGiftwrap();

    /**
     * Get checkout giftwrap message
     *
     * @return string|null
     */
    public function getCheckoutGiftwrapMessage();   

    /**
     * Set checkout already member
     *
     * @param string|null $checkoutAlreadyMember Already  member
     *
     * @return CustomFieldsInterface
     */
    public function setCheckoutAlreadyMember(string $checkoutAlreadyMember = null);

    /**
     * Set checkout club id
     *
     * @param string|null $checkoutClubId Club Id
     *
     * @return CustomFieldsInterface
     */
    public function setCheckoutClubId(string $checkoutClubId = null);

    /**
     * Set checkout giftwrap
     *
     * @param string|null $checkoutGiftwrap Giftwrap
     *
     * @return CustomFieldsInterface
     */
    public function setCheckoutGiftwrap(string $checkoutGiftwrap = null);

    /**
     * Set checkout giftwrap message
     *
     * @param string|null $checkoutGiftwrapMessage Giftwrap message
     *
     * @return CustomFieldsInterface
     */
    public function setCheckoutGiftwrapMessage(string $checkoutGiftwrapMessage = null);
}
