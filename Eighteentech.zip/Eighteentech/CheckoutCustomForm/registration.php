<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Eighteentech_CheckoutCustomForm',
    __DIR__
);
