<?php

namespace Eighteentech\CheckoutCustomForm\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Eighteentech\CheckoutCustomForm\Api\Data\CustomFieldsInterface;

/**
 * Class AddCustomFieldsToOrder
 *
 * @category Observer
 * @package  Eighteentech\CheckoutCustomForm\Observer
 */
class AddCustomFieldsToOrder implements ObserverInterface
{
    /**
     * Execute observer method.
     *
     * @param Observer $observer Observer
     *
     * @return void
     */
    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        $quote = $observer->getEvent()->getQuote();

        $order->setData(
            CustomFieldsInterface::CHECKOUT_ALREADY_MEMBER,
            $quote->getData(CustomFieldsInterface::CHECKOUT_ALREADY_MEMBER)
        );
        $order->setData(
            CustomFieldsInterface::CHECKOUT_CLUB_ID,
            $quote->getData(CustomFieldsInterface::CHECKOUT_CLUB_ID)
        );
        $order->setData(
            CustomFieldsInterface::CHECKOUT_GIFTWRAP,
            $quote->getData(CustomFieldsInterface::CHECKOUT_GIFTWRAP)
        );
        $order->setData(
            CustomFieldsInterface::CHECKOUT_GIFTWRAP_MESSAGE,
            $quote->getData(CustomFieldsInterface::CHECKOUT_GIFTWRAP_MESSAGE)
        );       
    }
}
