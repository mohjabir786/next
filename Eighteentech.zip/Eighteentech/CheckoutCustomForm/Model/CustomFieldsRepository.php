<?php
namespace Eighteentech\CheckoutCustomForm\Model;

use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Sales\Model\Order;
use Eighteentech\CheckoutCustomForm\Api\CustomFieldsRepositoryInterface;
use Eighteentech\CheckoutCustomForm\Api\Data\CustomFieldsInterface;

/**
 * Class CustomFieldsRepository
 *
 * @category Model/Repository
 * @package  Eighteentech\CheckoutCustomForm\Model
 */
class CustomFieldsRepository implements CustomFieldsRepositoryInterface
{
    /**
     * Quote repository.
     *
     * @var CartRepositoryInterface
     */
    protected $cartRepository;

    /**
     * ScopeConfigInterface
     *
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * CustomFieldsInterface
     *
     * @var CustomFieldsInterface
     */
    protected $customFields;

    /**
     * CustomFieldsRepository constructor.
     *
     * @param CartRepositoryInterface $cartRepository CartRepositoryInterface
     * @param ScopeConfigInterface    $scopeConfig    ScopeConfigInterface
     * @param CustomFieldsInterface   $customFields   CustomFieldsInterface
     */
    public function __construct(
        CartRepositoryInterface $cartRepository,
        ScopeConfigInterface $scopeConfig,
        CustomFieldsInterface $customFields
    ) {
        $this->cartRepository = $cartRepository;
        $this->scopeConfig    = $scopeConfig;
        $this->customFields   = $customFields;
    }
    /**
     * Save checkout custom fields
     *
     * @param int                                                      $cartId       Cart id
     * @param \Eighteentech\CheckoutCustomForm\Api\Data\CustomFieldsInterface $customFields Custom fields
     *
     * @return \Eighteentech\CheckoutCustomForm\Api\Data\CustomFieldsInterface
     * @throws CouldNotSaveException
     * @throws NoSuchEntityException
     */
    public function saveCustomFields(
        int $cartId,
        CustomFieldsInterface $customFields
    ): CustomFieldsInterface {
        $cart = $this->cartRepository->getActive($cartId);
        if (!$cart->getItemsCount()) {
            throw new NoSuchEntityException(__('Cart %1 is empty', $cartId));
        }

        try {
            $cart->setData(
                CustomFieldsInterface::CHECKOUT_ALREADY_MEMBER,
                $customFields->getCheckoutAlreadyMember()
            );
            $cart->setData(
                CustomFieldsInterface::CHECKOUT_CLUB_ID,
                $customFields->getCheckoutClubId()
            );
            $cart->setData(
                CustomFieldsInterface::CHECKOUT_GIFTWRAP,
                $customFields->getCheckoutGiftwrap()
            );
            $cart->setData(
                CustomFieldsInterface::CHECKOUT_GIFTWRAP_MESSAGE,
                $customFields->getCheckoutGiftwrapMessage()
            );           

            $this->cartRepository->save($cart);
        } catch (\Exception $e) {
            throw new CouldNotSaveException(__('Custom order data could not be saved!'));
        }

        return $customFields;
    }

    /**
     * Get checkout custom fields by given order id
     *
     * @param Order $order Order
     *
     * @return CustomFieldsInterface
     * @throws NoSuchEntityException
     */
    public function getCustomFields(Order $order): CustomFieldsInterface
    {
        if (!$order->getId()) {
            throw new NoSuchEntityException(__('Order %1 does not exist', $order));
        }

        $this->customFields->setCheckoutAlreadyMember(
            $order->getData(CustomFieldsInterface::CHECKOUT_ALREADY_MEMBER)
        );
        $this->customFields->setCheckoutClubId(
            $order->getData(CustomFieldsInterface::CHECKOUT_CLUB_ID)
        );
        $this->customFields->setCheckoutGiftwrap(
            $order->getData(CustomFieldsInterface::CHECKOUT_GIFTWRAP)
        );
        $this->customFields->setCheckoutGiftwrapMessage(
            $order->getData(CustomFieldsInterface::CHECKOUT_GIFTWRAP_MESSAGE)
        );    

        return $this->customFields;
    }
}
