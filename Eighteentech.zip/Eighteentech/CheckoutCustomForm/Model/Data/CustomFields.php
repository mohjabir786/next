<?php
namespace Eighteentech\CheckoutCustomForm\Model\Data;

use Magento\Framework\Api\AbstractExtensibleObject;
use Eighteentech\CheckoutCustomForm\Api\Data\CustomFieldsInterface;

/**
 * Class CustomFields
 *
 * @category Model/Data
 * @package  Eighteentech\CheckoutCustomForm\Model\Data
 */
class CustomFields extends AbstractExtensibleObject implements CustomFieldsInterface
{
    /**
     * Get checkout already member
     *
     * @return string|null
     */
    public function getCheckoutAlreadyMember()
    {
        return $this->_get(self::CHECKOUT_ALREADY_MEMBER);
    }

    /**
     * Get checkout club id
     *
     * @return string|null
     */
    public function getCheckoutClubId()
    {
        return $this->_get(self::CHECKOUT_CLUB_ID);
    }

    /**
     * Get checkout giftwrap
     *
     * @return string|null
     */
    public function getCheckoutGiftwrap()
    {
        return $this->_get(self::CHECKOUT_GIFTWRAP);
    }

    /**
     * Get checkout giftwrap message
     *
     * @return string|null
     */
    public function getCheckoutGiftwrapMessage()
    {
        return $this->_get(self::CHECKOUT_GIFTWRAP_MESSAGE);
    }

    
    /**
     * Set checkout buyer name
     *
     * @param string|null $checkoutBuyerName Buyer name
     *
     * @return CustomFieldsInterface
     */
    public function setCheckoutAlreadyMember(string $checkoutAlreadyMember = null)
    {
        return $this->setData(self::CHECKOUT_ALREADY_MEMBER, $checkoutAlreadyMember);
    }

    /**
     * Set checkout buyer email
     *
     * @param string|null $checkoutBuyerEmail Buyer email
     *
     * @return CustomFieldsInterface
     */
    public function setCheckoutClubId(string $checkoutClubId = null)
    {
        return $this->setData(self::CHECKOUT_CLUB_ID, $checkoutClubId);
    }

    /**
     * Set checkout purchase order number
     *
     * @param string|null $checkoutPurchaseOrderNo Purchase order number
     *
     * @return CustomFieldsInterface
     */
    public function setCheckoutGiftwrap(string $checkoutGiftwrap = null)
    {
        return $this->setData(self::CHECKOUT_GIFTWRAP, $checkoutGiftwrap);
    }

    /**
     * Set checkout goods mark
     *
     * @param string|null $checkoutGoodsMark Goods mark
     *
     * @return CustomFieldsInterface
     */
    public function setCheckoutGiftwrapMessage(string $checkoutGiftwrapMessage = null)
    {
        return $this->setData(self::CHECKOUT_GIFTWRAP_MESSAGE, $checkoutGiftwrapMessage);
    }   
}
