<?php
namespace Eighteentech\Career\Block\Adminhtml\Career;


class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{
    
    protected $_collectionFactory;

    
    protected $_career;
    protected $_interestCollectionFactory;
    protected $_positionCollectionFactory;
    protected $_locationCollectionFactory;

    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Eighteentech\Career\Model\Career $career,
        \Eighteentech\Career\Model\ResourceModel\Interest\CollectionFactory $interestCollectionFactory,
        \Eighteentech\Career\Model\ResourceModel\Position\CollectionFactory $positionCollectionFactory,
        \Eighteentech\Career\Model\ResourceModel\Career\CollectionFactory $collectionFactory,
        \Amasty\Storelocator\Model\ResourceModel\Location\CollectionFactory  $locationCollectionFactory,
        array $data = []
    ) {
        $this->_collectionFactory = $collectionFactory;
        $this->_interestCollectionFactory = $interestCollectionFactory;
        $this->_positionCollectionFactory = $positionCollectionFactory;
        $this->_locationCollectionFactory = $locationCollectionFactory;
        $this->_career = $career;
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('careerGrid');
        $this->setDefaultSort('career_id');
        $this->setDefaultDir('DESC');
        $this->setUseAjax(true);
        $this->setSaveParametersInSession(true);
    }

    /**
     * Prepare collection
     *
     * @return \Magento\Backend\Block\Widget\Grid
     */
    protected function _prepareCollection()
    {
        $collection = $this->_collectionFactory->create();        
        $this->setCollection($collection);

        return parent::_prepareCollection();
    }

    /**
     * Prepare columns
     *
     * @return \Magento\Backend\Block\Widget\Grid\Extended
     */
    protected function _prepareColumns()
    {
        $this->addColumn('career_id', [
            'header'    => __('ID'),
            'index'     => 'career_id',
        ]);
        
        $this->addColumn('name', ['header' => __('Name'), 'index' => 'name']);
        $this->addColumn('email', ['header' => __('Email'), 'index' => 'email']);
        $this->addColumn('telephone', ['header' => __('Telephone'), 'index' => 'telephone']);
        $this->addColumn('interest_id', ['header' => __('Interest'), 'index' => 'interest_id', 'type' => 'options','options' =>$this->getInterestList()]);
        $this->addColumn('position_id', ['header' => __('Position'), 'index' => 'position_id','type' => 'options','options' =>$this->getPositionList()]);     
        $this->addColumn('store_location', ['header' => __('Store Location'), 'index' => 'store_location', 'type' => 'options','options' =>$this->getLocationList()]);
        $this->addColumn('current_location', ['header' => __('Current Location'), 'index' => 'current_location']);
        $this->addColumn('current_ctc', ['header' => __('Current CTC'), 'index' => 'current_ctc']);
        $this->addColumn('linkedin_profile', ['header' => __('Linkedin Profile'), 'index' => 'linkedin_profile']);
        
        
        $this->addColumn(
            'resume',
            [
                'header' => __('Resume'),                
                'index'  => 'resume',
                'renderer'=>'Eighteentech\Career\Block\Adminhtml\Career\Edit\Tab\Renderer\Url'
            ]
        );
        
        /*$this->addColumn('is_active', ['header' => __('Active'), 'index' => 'is_active', 'type' => 'options',
                   'options' =>['1' => __('Active'), '0' => __('Inactive')]]);
        
        $this->addColumn(
            'creation_time',
            [
                'header' => __('Created'),
                'index' => 'creation_time',
                'type' => 'datetime',
                'header_css_class' => 'col-date',
                'column_css_class' => 'col-date'
            ]
        );
        
        $this->addColumn(
            'action',
            [
                'header' => __('Edit'),
                'type' => 'action',
                'getter' => 'getId',
                'actions' => [
                    [
                        'caption' => __('Edit'),
                        'url' => [                            
                            'params' => ['store' => $this->getRequest()->getParam('store')]
                        ],
                        'field' => 'career_id'
                    ]
                ],
                'sortable' => false,
                'filter' => false,
                'header_css_class' => 'col-action',
                'column_css_class' => 'col-action'
            ]
        );*/

        return parent::_prepareColumns();
    }

    /**
     * Row click url
     *
     * @param \Magento\Framework\Object $row
     * @return string
     */
    public function getRowUrl($row)
    {
        return $this->getUrl('*/*/edit', ['career_id' => $row->getId()]);
    }

    /**
     * Get grid url
     *
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('*/*/grid', ['_current' => true]);
    }
    
    public function getInterestList(){
		
		$interestList = array();
		$interestCollection = $this->_interestCollectionFactory->create();
		if($interestCollection->getSize()){
			foreach($interestCollection as $interest){
				$interestList[$interest->getId()] = $interest->getTitle();
			}
		}
		
		return $interestList;
	}
	
	
	public function getPositionList(){
		
		$positionList = array();
		$positionCollection = $this->_positionCollectionFactory->create();
		if($positionCollection->getSize()){
			foreach($positionCollection as $position){
				$positionList[$position->getId()] = $position->getTitle();
			}
		}
		
		return $positionList;
	}
	
	public function getLocationList(){
		
		$locationList = array();
		$locationCollection = $this->_locationCollectionFactory->create();
		if($locationCollection->getSize()){
			foreach($locationCollection as $location){
				$locationList[$location->getId()] = $location->getName();
			}
		}
		
		return $locationList;
	}
}
