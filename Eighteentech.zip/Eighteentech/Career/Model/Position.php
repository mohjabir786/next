<?php
namespace Eighteentech\Career\Model;


class Position extends \Magento\Framework\Model\AbstractModel
{
   
    protected function _construct()
    {
        $this->_init('Eighteentech\Career\Model\ResourceModel\Position');
    }

}
