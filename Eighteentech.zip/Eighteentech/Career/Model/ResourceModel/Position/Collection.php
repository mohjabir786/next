<?php
/**
 * Position Resource Collection
 */
namespace Eighteentech\Career\Model\ResourceModel\Position;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Eighteentech\Career\Model\Position', 'Eighteentech\Career\Model\ResourceModel\Position');
    }
}
