<?php
/**
 * Interest Resource Collection
 */
namespace Eighteentech\Career\Model\ResourceModel\Interest;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Eighteentech\Career\Model\Interest', 'Eighteentech\Career\Model\ResourceModel\Interest');
    }
}
