<?php
/**
 * Career Resource Collection
 */
namespace Eighteentech\Career\Model\ResourceModel\Career;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Eighteentech\Career\Model\Career', 'Eighteentech\Career\Model\ResourceModel\Career');
    }
}
