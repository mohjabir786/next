<?php
namespace Eighteentech\Career\Model;


class Career extends \Magento\Framework\Model\AbstractModel
{
   
    protected function _construct()
    {
        $this->_init('Eighteentech\Career\Model\ResourceModel\Career');
    }

}
