<?php
namespace Eighteentech\Career\Model;


class Interest extends \Magento\Framework\Model\AbstractModel
{
   
    protected function _construct()
    {
        $this->_init('Eighteentech\Career\Model\ResourceModel\Interest');
    }

}
