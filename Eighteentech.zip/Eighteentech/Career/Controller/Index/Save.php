<?php
namespace Eighteentech\Career\Controller\Index;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Image\AdapterFactory;
use Magento\Framework\Filesystem;

class Save extends \Magento\Framework\App\Action\Action
{

    const XML_PATH_EMAIL_RECIPIENT_NAME = 'trans_email/ident_support/name';
    const XML_PATH_EMAIL_RECIPIENT_EMAIL = 'trans_email/ident_support/email';
     
    protected $_inlineTranslation;
    protected $_transportBuilder;
    protected $_scopeConfig;
    protected $_logLoggerInterface;
    protected $_careerFactory;
    protected $uploaderFactory;
    protected $adapterFactory;
    protected $filesystem;   
    
    
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
       \Eighteentech\Career\Model\CareerFactory $careerFactory,
        UploaderFactory $uploaderFactory,
        AdapterFactory $adapterFactory,
        Filesystem $filesystem,
         \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Psr\Log\LoggerInterface $loggerInterface
        ){
        $this->_careerFactory = $careerFactory;
        $this->uploaderFactory = $uploaderFactory;
        $this->adapterFactory = $adapterFactory;
        $this->filesystem = $filesystem;
        $this->_inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
        $this->_scopeConfig = $scopeConfig;
        $this->_logLoggerInterface = $loggerInterface;        
        parent::__construct($context);
    }
    
    public function execute()
    {
		
		$data = $this->getRequest()->getPostValue();
		$careerObj = $this->_careerFactory->create();		
		if($this->validateData($data)){
			if(isset($_FILES['resume']['name']) && $_FILES['resume']['name'] != '') {
				try{
					$uploaderFactory = $this->uploaderFactory->create(['fileId' => 'resume']);
					$uploaderFactory->setAllowedExtensions(['pdf', 'doc', 'docx']);
					$imageAdapter = $this->adapterFactory->create();
					//$uploaderFactory->addValidateCallback('custom_image_upload',$imageAdapter,'validateUploadFile');
					$uploaderFactory->setAllowRenameFiles(true);
					$uploaderFactory->setFilesDispersion(true);
					$mediaDirectory = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA);
					$destinationPath = $mediaDirectory->getAbsolutePath('career/resume');
					//$result = $uploaderFactory->save($destinationPath);
					$random_fileName = 'Resume_'.time();
					$result = $uploaderFactory->save($destinationPath,$random_fileName.'.'.$uploaderFactory->getFileExtension());
					if (!$result) {
						throw new LocalizedException(
							__('File cannot be saved to path: $1', $destinationPath)
						);
					}
					$imagePath = 'career/resume'.$result['file'];
					$data['resume'] = $imagePath;
				} catch (\Exception $e) {
				}
			}
			unset($data['form_key']);
			unset($data['submit_btn']);
			$careerObj->setData($data)->save();
			$this->sendReplyEmail($data);
			$this->sendHrEmail($data);
			
			$this->messageManager->addSuccess('Your Application has been submitted successfully.');
		}else{
			$this->messageManager->addError('Please fill all the required fields.');
		}	
        
        
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('*/*/');
    }
    
    
    public function validateData($data){
		$require_field = array('name', 'email', 'telephone', 'interest_id','position_id','current_location','resume');
		foreach($data as $key => $val){
			  if(in_array($key,$require_field)){
				 if($val == '')
				  return false;  
			   }
			}
		return true;			
	}
	
	
	public function sendReplyEmail($data){
		try
        {
			// Send Mail
            $this->_inlineTranslation->suspend();
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;             
            
             
            $senderEmail = $this->_scopeConfig ->getValue('trans_email/ident_general/email',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
             
            $senderName = $this->_scopeConfig ->getValue('trans_email/ident_general/name',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            
            $sentToEmail = $data['email'];
            $sentToName = $data['name'];
            $sender = [
                'name' => $senderName,
                'email' => $senderEmail
            ]; 
             
             
            $transport = $this->_transportBuilder
            ->setTemplateIdentifier('career_email_template')
            ->setTemplateOptions(
                [
                    'area' => 'frontend',
                    'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                ]
                )
                ->setTemplateVars([
                    'name'  => $data['name'],
                    'email'  => $data['email']
                ])
                ->setFrom($sender)
                ->addTo($sentToEmail,$sentToName)
                //->addTo('owner@example.com','owner')
                ->getTransport();
                 
                $transport->sendMessage();
                 
                $this->_inlineTranslation->resume();               
                 
        } catch(\Exception $e){
            $this->messageManager->addError($e->getMessage());
            $this->_logLoggerInterface->debug($e->getMessage());
            exit;
        }
	}
	
	public function sendHrEmail($data){
		
		try
        {
            // Send Mail
            $this->_inlineTranslation->suspend();
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;             
           
            
            $detailContent = '<table>
                              <tr>
                                  <td>Applicant Name: </td><td>'.$data['name'].'</td>
                              </tr>
                              <tr>
                                  <td>Email: </td><td>'.$data['email'].'</td>
                              </tr>
                              <tr>
                                  <td>Contact No.</td><td>'.$data['telephone'].'</td>
                              </tr>
                              <tr>
                                  <td>Area Of Interest</td><td>'.$data['interest_id'].'</td>
                              </tr>
                              <tr>
                                  <td>Position</td><td>'.$data['position_id'].'</td>
                              </tr>
                              <tr>
                                  <td>Store Location</td><td>'.$data['store_location'].'</td>
                              </tr>
                              <tr>
                                  <td>Current Location</td><td>'.$data['current_location'].'</td>
                              </tr>
                              <tr>
                                  <td>Current CTC</td><td>'.$data['current_ctc'].'</td>
                              </tr>
                              <tr>
                                  <td>Linkedin Profile</td><td>'.$data['linkedin_profile'].'</td>
                              </tr>
                              </table>';
             
            $senderEmail = $this->_scopeConfig ->getValue('trans_email/ident_general/email',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
             
            $senderName = $this->_scopeConfig ->getValue('trans_email/ident_general/name',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            
            //$sentToEmail = 'hr@forestessentialsindia.com';
            $sentToEmail = $this->_scopeConfig ->getValue('career/general/hr_email',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $sentToName = 'HR';
            $sender = [
                'name' => $senderName,
                'email' => $senderEmail
            ]; 
             
            $transport = $this->_transportBuilder
            ->setTemplateIdentifier('forest_hr_email_template')
            ->setTemplateOptions(
                [
                    'area' => 'frontend',
                    'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                ]
                )
                ->setTemplateVars([
                    'applicant_details'  => $detailContent,
                    'name' => $data['name'],
                    'email'  => $data['email']
                ])
                ->setFrom($sender)
                ->addTo($sentToEmail,$sentToName)
                //->addTo('owner@example.com','owner')
                ->getTransport();
                 
                $transport->sendMessage();
                 
                $this->_inlineTranslation->resume();               
                 
        } catch(\Exception $e){
            $this->messageManager->addError($e->getMessage());
            $this->_logLoggerInterface->debug($e->getMessage());
            exit;
        }
	}	
}
