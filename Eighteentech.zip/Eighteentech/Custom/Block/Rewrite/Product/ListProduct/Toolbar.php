<?php
namespace Eighteentech\Custom\Block\Rewrite\Product\ListProduct; 
    class Toolbar extends \Magento\Catalog\Block\Product\ProductList\Toolbar
    {
        
        public function setCollection($collection) 
        {
			$this->_collection = $collection;
			$this->_collection->setCurPage($this->getCurrentPage());

			// we need to set pagination only if passed value integer and more that 0
			$limit = (int)$this->getLimit();
			if ($limit) {
				$this->_collection->setPageSize($limit);
			}
            
			// switch between sort order options
			if($this->getRequest()->getParam('product_list_order') == 'rating'){
				$joinConditions = 'e.entity_id = rating_option_vote_aggregated.entity_pk_value';
				//$this->_collection->addAttributeToSelect('*');
				$this->_collection->getSelect()->joinLeft(
							 ['rating_option_vote_aggregated'],
							 $joinConditions,
							 ["rating_option_vote_aggregated.percent"]
							)->group('e.entity_id')->order('rating_option_vote_aggregated.percent DESC');
			}
			elseif ($this->getCurrentOrder()) {				
					
			  $this->_collection->setOrder($this->getCurrentOrder(), $this->getCurrentDirection());
						
				
			}

			 /*echo '<pre>';
			 var_dump($_REQUEST['product_list_order']);
			 var_dump((string) $this->_collection->getSelect());
			 die;*/
			 

			return $this;
		}
}
