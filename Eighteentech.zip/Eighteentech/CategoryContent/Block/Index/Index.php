<?php
namespace Eighteentech\CategoryContent\Block\Index;
class Index extends \Magento\Framework\View\Element\Template
{
	protected $templateProcessor;
	protected $_registry;
	public function __construct(
	    \Magento\Framework\View\Element\Template\Context $context,
	    \Zend_Filter_Interface $templateProcessor,
	     \Magento\Framework\Registry $registry
	)
	{
		parent::__construct($context);
		$this->templateProcessor = $templateProcessor;
		$this->_registry = $registry;
	}

	public function filterOutputHtml($string) 
	{
		return $this->templateProcessor->filter($string);
	}
	public function CategoryContent(){
		
		return $this->_registry->registry('current_category');
	}
	
}
