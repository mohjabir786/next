<?php
namespace Eighteentech\Customer\Block;
class Custom extends \Magento\Framework\View\Element\Template
{
    protected $_customerSession;
    protected $_customerFactory;
         
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Model\SessionFactory $customerSession,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        array $data = []
    ) {
        $this->_customerSession = $customerSession->create();
        $this->_customerFactory = $customerFactory;
        parent::__construct($context, $data);
    }
     
    public function getLoggedinCustomerId() {
        if ($this->_customerSession->isLoggedIn()) {
            return $this->_customerSession->getId();
        }
        return false;
    }
 
    public function getCustomerData() {
        if ($this->_customerSession->isLoggedIn()) {
            //return $this->_customerSession->getCustomerData();
            $custData = $this->_customerSession->getCustomerData();
            return $this->_customerFactory->create()->load($custData->getId());
        }
        return false;
    }
}
