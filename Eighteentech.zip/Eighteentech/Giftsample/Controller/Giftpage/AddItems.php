<?php 
namespace Eighteentech\Giftsample\Controller\Giftpage;
 
 use Magento\Framework\Controller\ResultFactory;
 use Magento\Framework\App\Action\Action;
 use Magento\Framework\App\Action\Context;

class AddItems extends \Magento\Framework\App\Action\Action
{

    protected $formKey;   
    protected $cart;
    protected $product;
    protected $_scopeConfig;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Catalog\Model\ProductFactory $product,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        array $data = []
    ) {
        $this->formKey = $formKey;
        $this->cart = $cart;
        $this->product = $product; 
        $this->_scopeConfig = $scopeConfig;     
        parent::__construct($context);
    }

    public function execute()
    {		
        $selectedItems = $this->getRequest()->getPost('selectedItems');       
        $selectedItems = explode(",",$selectedItems);
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $allItems = $this->cart->getQuote()->getItems();
        $giftProducts = $this->getProductIds();
        
           
        try{
		foreach ($allItems as $item) {
			
            $itemId = $item->getItemId();
            $pdId = $item->getProductId();
            
            if(in_array($pdId,$giftProducts))
            $this->cart->removeItem($itemId)->save();
        }	
			
        foreach ($selectedItems as $key => $selectedItem) {

            $params = array(
                'form_key' => $this->formKey->getFormKey(),
                'product_id' => $selectedItem, //product Id
                'qty'   =>1 //quantity of product                
            );
            $_product = $this->product->create()->load($selectedItem);       
            $this->cart->addProduct($_product, $params);
        }
            $this->cart->save();
            $this->messageManager->addSuccess('Gift Sample added succesfully.');
            $status = 1;
            $resultRedirect->setUrl($this->getCheckoutUrl());
            
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addException($e,__('%1', $e->getMessage()));
            $status = 0;
            $resultRedirect->setUrl($this->getGiftPageUrl());
        } catch (\Exception $e) {
            $this->messageManager->addException($e, __('error.'));
            $status = 0;
            $resultRedirect->setUrl($this->getGiftPageUrl());
        }
        $result = array();
        $result['status'] = $status;
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($result);
        return $resultJson;
        
        
        //return $resultRedirect;
    }
    
    
    private function getCheckoutUrl()
    {
        return $this->_url->getUrl('checkout/index', ['_secure' => true]);
    }
    
    private function getGiftPageUrl()
    {
        return $this->_url->getUrl('giftsample/giftpage/', ['_secure' => true]);
    }
    
    
    public function getProductIds(){
		$sampleProductIds = $this->_scopeConfig ->getValue('giftsample/general/gift_sample_ids',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		return explode(',',$sampleProductIds);
	}
}
