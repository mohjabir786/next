<?php

namespace Eighteentech\Giftsample\Controller\Giftpage;
use Magento\Framework\Controller\ResultFactory;
class Index extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_scopeConfig;
	protected $cart;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Magento\Checkout\Model\Cart $cart
		)
		{
			$this->_scopeConfig = $scopeConfig;
			$this->_pageFactory = $pageFactory;
			$this->cart = $cart;
			return parent::__construct($context);
		}

	public function execute()
	{
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		if(!$this->checkForSample()){
			$resultRedirect->setUrl($this->getCheckoutUrl());	
			return $resultRedirect;
		}
		
		$page = $this->_pageFactory->create();
		$page->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0', true);
		
		return $page;
	}
	
	
	public function checkForSample(){		
		$giftSampleEnable = $this->_scopeConfig ->getValue('giftsample/general/enable',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		if(!$giftSampleEnable)
		return false;
		
		$subTotal = $this->cart->getQuote()->getGrandTotal();
		
		$minOrderAmount = $this->_scopeConfig ->getValue('giftsample/general/min_order_amount',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);		
		
		if($subTotal < $minOrderAmount){
			return false;
		}else
		return true;
		
	}
	
	 private function getCheckoutUrl()
	{
        return $this->_url->getUrl('checkout/index', ['_secure' => true]);
    }

}
