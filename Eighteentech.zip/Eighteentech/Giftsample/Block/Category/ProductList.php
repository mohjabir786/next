<?php

namespace Eighteentech\Giftsample\Block\Category;

use Magento\Framework\View\Element\AbstractBlock;
use Magento\Framework\Registry;

class ProductList extends \Magento\Catalog\Block\Product\AbstractProduct
{
	protected $_itemCollection;
	protected $_productCollectionFactory;
	protected $_categoryFactory;
	protected $_scopeConfig;
	protected $cart;
	protected $_productFactory;

public function __construct(
        \Magento\Catalog\Block\Product\Context $context,       
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,        
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Magento\Checkout\Model\Cart $cart,
        Registry $registry,      
        array $data = []
    ) {
        
        $this->_scopeConfig = $scopeConfig;			
		$this->cart = $cart;
        $this->_productCollectionFactory = $productCollectionFactory;       
        $this->_categoryFactory = $categoryFactory;
        $this->_productFactory = $productFactory;
        $this->registry = $registry;
        parent::__construct(
            $context,
            $data
        );
    }   
    
    
    public function getItems(){
		
		if($this->getMinAmount() > $this->getOrderTotal())
		return false;
		
		if($giftCategory = $this->getGiftCategory()){
		//return $this->getProductCollection($giftCategory);
		 //$productItems = [551,550,525,524,170];
		 $productItems  = $this->getProductIds();
		 return $productItems;
		}
	}
     

    public function getCategory($categoryId) 
    {
        $category = $this->_categoryFactory->create();
        $category->load($categoryId);
        return $category;
    }
    
    
    public function getCategoryProducts($categoryId) 
    {
        $products = $this->getCategory($categoryId)->getProductCollection()->addFieldToFilter('visibility', array('eq' => 1));
        $products->addAttributeToSelect('*');
        return $products;
    }
   
    
    public function canItemsAddToCart()
    {
        foreach ($this->getItems() as $item) {
            if (!$item->isComposite() && $item->isSaleable() && !$item->getRequiredOptions()) {
                return true;
            }
        }
        return false;
    }
    
    public function getPageTitle(){
		return $this->_scopeConfig ->getValue('giftsample/general/page_title',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		
	}
	
	public function getPageDescription(){
		$pageDescription =  $this->_scopeConfig ->getValue('giftsample/general/page_description',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$itemNo = $this->getItemNumber();
		
		return str_replace('[++Item_no]', $itemNo,  $pageDescription);
		
	}
	
	public function getOrderTotal(){
		return $this->cart->getQuote()->getGrandTotal();
	}
	
	
	public function getMinAmount(){
		return $this->_scopeConfig ->getValue('giftsample/general/min_order_amount',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
	}
	
	public function getGiftCategory(){		
		return $this->_scopeConfig ->getValue('giftsample/general/category_id',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
	}
	
	
	public function getItemNumber(){
		$max_gift = 6;
		$step_counter = $this->_scopeConfig ->getValue('giftsample/general/step_counter',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$minimum_gift = $this->_scopeConfig ->getValue('giftsample/general/minimum_gift',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$minAmount = $this->getMinAmount();
		$orderTotal = $this->getOrderTotal();
		$balanceAmount = $orderTotal - $minAmount;
		if($orderTotal < $minAmount){
			return 0;
		}
		elseif($balanceAmount < $step_counter ){
			return $minimum_gift;
		}else{
			$divisionTime =  floor($balanceAmount/$step_counter);			
			$totalGift = $divisionTime + $minimum_gift;
			
			if($totalGift < $max_gift)
				return $totalGift;
			else 
				return $max_gift;
		}
	}
	
	
	public function getProductCollection($categoryId)
	{
		//$categoryId = 'yourcategoryid';
		$category = $this->_categoryFactory->create()->load($categoryId);
		$collection = $this->_productCollectionFactory->create();
		$collection->addAttributeToSelect('*');
		$collection->addCategoryFilter($category);
		$collection->setVisibility(null);
		//$collection->addAttributeToFilter('visibility', \Magento\Catalog\Model\Product\Visibility::VISIBILITY_NOT_VISIBLE);
		$collection->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);
		return $collection;
	}
	
	public function getProductData($productId){
		return $this->_productFactory->create()->load($productId);
	}
	
	 public function checkGiftSample(){		
		$giftSampleEnable = $this->_scopeConfig ->getValue('giftsample/general/enable',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		if(!$giftSampleEnable)
		return false;
		
		$subTotal = $this->getOrderTotal();
		
		$minOrderAmount = $this->getMinAmount();
		
		if($subTotal < $minOrderAmount){
			return false;
		}else
		return true;
		
	}
	
	public function getProductIds(){
		$sampleProductIds = $this->_scopeConfig ->getValue('giftsample/general/gift_sample_ids',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		return explode(',',$sampleProductIds);
	}
	
	
	public function getCartItems(){
		$items = $this->cart->getQuote()->getItems();
		$cartItems = array();
		foreach($items as $item){
			$cartItems[] = $item->getProductId();
		}
		return $cartItems;
	}
	
	
	public function validateGiftSample(){
		$orderTotal = $this->getOrderTotal();
		$minOrderAmount = $this->getMinAmount();		
			
	    $allowGiftItem = $this->getItemNumber();
	    
	    $giftProductIds = $this->getProductIds();
	    $cartItems = $this->getCartItems();
	    
	    $giftInCart = array_intersect($cartItems,$giftProductIds);
	    
	    if(count($giftInCart) > $allowGiftItem)
			return false;
	    else
			return true;
	    		
	}
   
}
