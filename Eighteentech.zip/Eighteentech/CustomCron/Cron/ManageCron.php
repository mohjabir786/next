<?php

namespace Eighteentech\CustomCron\Cron;

class ManageCron
{
	protected $_helperData;
	protected $logger;

	public function __construct(
		\Eighteentech\CustomCron\Helper\Data $helperData,
		\Psr\Log\LoggerInterface $logger
	) {
		$this->_helperData = $helperData;
		$this->logger = $logger;
	}

	public function checkOrderStatus()
	{
		try {
			$this->_helperData->checkOrderStatus();
		} catch (\Exception $e) {
			$this->logger->debug($e->getMessage());
		}
	}
}