<?php

namespace Eighteentech\CustomCron\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use \Psr\Log\LoggerInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Sales\Model\Order;

class Data extends AbstractHelper
{
    const XML_FOREST_REP_EMAIL = 'customcron/general/forest_rep_email';

	protected $_storeManager;
	protected $timezone;
	protected $productRepository;
	protected $scopeConfig;
    protected $searchCriteriaBuilder;
    protected $logger;
    protected $_invoiceService;
    protected $_transaction;
    protected $_transportBuilder;
 
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Directory\Model\CountryFactory $countryFactory,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        LoggerInterface $logger,
        \Magento\Sales\Model\Service\InvoiceService $invoiceService,
        \Magento\Framework\DB\Transaction $transaction,
        \Magento\Sales\Model\Order\Email\Sender\InvoiceSender $invoiceSender,
        \Magento\Framework\Mail\Template\TransportBuilder $_transportBuilder
    ) {
        parent::__construct($context);
        $this->_orderRepository = $orderRepository;
        $this->timezone = $timezone;
        $this->productRepository = $productRepository;
        $this->scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
        $this->_countryFactory = $countryFactory;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->logger = $logger;
        $this->_invoiceService = $invoiceService;
        $this->_transaction = $transaction;
        $this->invoiceSender = $invoiceSender;
        $this->_transportBuilder = $_transportBuilder;
    }

    public function checkOrderStatus()
    {
    	try {
            /*$date = (new \DateTime())->modify('-12 hours');
            echo "==>".$date->format('Y-m-d H:i:s');*/
            $currentDate = $this->timezone->date()->format('Y-m-d H:i:s');
            $finalDate = date('Y-m-d H:i:s', strtotime($currentDate) - 60*60*1000);

            $searchCriteria = $this->searchCriteriaBuilder
                ->addFilter(
                    'status',
                    'complete',
                    'neq'
                )/*->addFilter(
                    'status',
                    'canceled',
                    'neq'
                )*/->addFilter(
                    'created_at',
                    //$date->format('Y-m-d'),
                    $finalDate,
                    'gt'
                )->create();

            $orders = $this->_orderRepository->getList($searchCriteria);
            $cancelledData = [];
            foreach ($orders->getItems() as $order) {
                //Your Code Here
                //echo "===>".$order->getIncrementId().'===>'.$order->getStatus().'===>'.$order->getId();
                //echo "<br>";
                //die();
                if ($order->getStatus() == 'canceled') {
                    $cancelledData[] = [
                        'order_id' => $order->getId(),
                        'order_inc_id' => $order->getIncrementId(),
                        'order_status' => $order->getStatus(),
                        'customer_name' => $order->getCustomerName(),
                        'customer_email' => $order->getCustomerEmail(),
                    ];
                    $this->sendCancelledOrderEmail($cancelledData);
                }
                // $this->logger->info("Order# {$order->getIncrementId()} - Creation Date: {$order->getCreatedAt()}");
            }
            if (!empty($cancelledData)) {

            }
        } catch (\Exception $e) {
            $this->logger->debug($e->getMessage());
        }
    }

    public function generateInvoice($orderId)
    {
        // $orderId = 1; //order id for which want to create invoice
        try {
            $order = $this->_orderRepository->get($orderId);
            if($order->canInvoice()) {
                $invoice = $this->_invoiceService->prepareInvoice($order);
                $invoice->register();
                $invoice->save();
                $transactionSave = $this->_transaction->addObject(
                    $invoice
                )->addObject(
                    $invoice->getOrder()
                );
                $transactionSave->save();
                $this->invoiceSender->send($invoice);
                //send notification code
                $order->addStatusHistoryComment(
                    __('Notified customer about invoice #%1.', $invoice->getId())
                )
                ->setIsCustomerNotified(true)
                ->save();

                $orderState = Order::STATE_PROCESSING;
                $order->setState($orderState)->setStatus(Order::STATE_PROCESSING);
                $order->save();
            }
        } catch (\Exception $e) {
            echo ">>>>".$e->getMessage();
        }
        
    }

    public function getForestRepEmail() {
        return $this->scopeConfig->getValue(self::XML_FOREST_REP_EMAIL, ScopeInterface::SCOPE_STORE);
    }

    public function sendCancelledOrderEmail($orderDetails) {
        $params['order_details'] = $this->getOrderEmailParams($orderDetails);
        try {
            $storeId = $this->_storeManager->getStore()->getId();
            $email = $this->getForestRepEmail();

            $name = 'Forest Essentials | Email';

            $transport = $this->_transportBuilder
                    ->setTemplateIdentifier('order_status_no_capture')
                    ->setTemplateOptions([
                        'area' => 'frontend',
                        'store' => $storeId
                    ])
                    ->setTemplateVars($params)
                    ->setFrom([
                        'name' => $name,
                        'email' => $email
                    ])
                    ->addTo($email)
                    /*->addCc($email)*/
                    /*->addBcc($this->_bccEmail)*/
                    ->getTransport();
            $transport->sendMessage();

            return true;
        } catch (\Exception $e) {
            $this->logger->debug($e->getMessage());
        }
        return false;
    }

    public function getOrderEmailParams($orderDetails)
    {
        $html = '';
        foreach ($orderDetails as $orderDetail) {
            $html.='<tr>';
            $html.='<td valign="top"><center>'.$orderDetail['order_id'].'</center></td>';
            $html.='<td valign="top"><center>'.$orderDetail['order_inc_id'].'</center></td>';
            $html.='<td valign="top"><center>'.$orderDetail['customer_name'].'</center></td>';
            $html.='<td valign="top"><center>'.$orderDetail['customer_email'].'</center></td>';
            $html.='<td valign="top"><center>'.$orderDetail['order_status'].'</center></td>';
            $html.='</tr>';
        }
        return $html;
    }
}