<?php
namespace Eighteentech\CustomCron\Setup;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
/**
 * @codeCoverageIgnore
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    public function upgrade(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $installer = $setup;
        $installer->startSetup();

        if (version_compare($context->getVersion(), '1.0.0', '<')) {
            $installer->getConnection()->addColumn(
                $installer->getTable('sales_order'),
                'order_cancel_cron',
                [
                    'type' => Table::TYPE_INTEGER,
                    'nullable' => false,
                    'comment' => 'Order Cancel Cron',
                    'unsigned' => true,
                    'default' => 0
                ]
            );
        }
        $setup->endSetup();
    }
}