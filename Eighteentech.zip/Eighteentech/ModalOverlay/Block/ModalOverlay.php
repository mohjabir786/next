<?php
namespace Eighteentech\ModalOverlay\Block;

use Magento\Cms\Api\BlockRepositoryInterface;
use Magento\Cms\Api\Data\BlockInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\ScopeInterface;

class ModalOverlay extends Template
{
    const POPUP_ENABLE = 'popup/general/enable';
    const POPUP_BLOCK_ID = 'popup/general/block_id';
    const POPUP_EXPIRE_TIME = 'popup/general/expire_time';
    private $blockRepository;
    protected $scopeConfig;
    protected $_cookieManager;
    protected $_cookieMetadataFactory;
    protected $_sessionManager;

    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,       
        BlockRepositoryInterface $blockRepository,
        Context $context,
        array $data = []
    ) {       
        $this->scopeConfig = $scopeConfig;
        $this->blockRepository = $blockRepository;
        parent::__construct($context, $data);
    }

    public function getContent()
    {
        $content = false;
        if($this->checkPopupStatus()){           
                try {
                    $blockId = $this->getBlockId();
                    /** @var BlockInterface $block */
                    $block = $this->blockRepository->getById($blockId);
                    $content = $block->getContent();
                } catch (LocalizedException $e) {
                    $content = false;
                }
            
        }

        return $content;
    }


    public function checkPopupStatus(){
        return $this->scopeConfig->getValue(self::POPUP_ENABLE, ScopeInterface::SCOPE_STORE);
    }

    public function getBlockId(){
        return $this->scopeConfig->getValue(self::POPUP_BLOCK_ID, ScopeInterface::SCOPE_STORE);
    }

    public function getExpireTime(){
        return $this->scopeConfig->getValue(self::POPUP_EXPIRE_TIME, ScopeInterface::SCOPE_STORE);
    }

}