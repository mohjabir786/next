<?php

namespace Eighteentech\Ship\Helper;

use Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
	protected $_storeManager;
	protected $timezone;
	protected $productRepository;
	protected $scopeConfig;
 
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Directory\Model\CountryFactory $countryFactory
    ) 
    {
        parent::__construct($context);
        $this->_orderRepository = $orderRepository;
        $this->timezone = $timezone;
        $this->productRepository = $productRepository;
        $this->scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
        $this->_countryFactory = $countryFactory;
    }

	public function getHtml(
		$incrementId,
		$AWBNo,
		$DestinationArea,
		$DestinationLocation,
		$custcode
	) {
		try {
			$order	= $order = $this->_orderRepository->get($incrementId);
			$order_id = $order->getIncrementId(); 
			$AWB_No = $AWBNo; 
			$des_area = $DestinationArea; 
			$des_loc = $DestinationLocation; 
			$order_date = $this->timezone->date(new \DateTime($order->getCreatedAtStoreDate()))->format('d-M-Y');
			
			$address = '';
			$shipping_address = $order->getShippingAddress();
			$cust_name = $shipping_address->getFirstname().' '.$shipping_address->getLastname();
			$payment_method_code = $order->getPayment()->getMethodInstance()->getCode(); //cashondelivery

			$collectableAmount = '';
			$SubProductCode = 'p';
			$pdf_method = "PREPAID ORDER";

			if(($payment_method_code == 'phoenix_cashondelivery') || 
				($payment_method_code == 'cashondelivery') || 
				($payment_method_code == 'msp_cashondelivery')
			) {
				$collectableAmount = $order->getGrandTotal(); 
				$SubProductCode = 'c';
				$pdf_method = "CASH ON DELIVERY (COD)"; 
			}

			$i = 1;
			$qty = 0;
			$mrp = 0;
			$weight = 0;
			$ordered_items = $order->getAllItems();
			$commodityDetail = array();
			
			foreach($ordered_items as $item)
			{    
			    if(!$item->getParentItemId())
			    {	
					$item->getItemId();
					$item->getSku();
					$product = $this->productRepository->get($item->getSku());
					$qty = $qty + $item->getQtyOrdered();     
					$mrp = $mrp + $item->getPrice(); 
					$weight += ($product->getWeight() * $item->getQtyOrdered())/1000 ; 
					$commodityDetail['CommodityDetail'.$i] =  preg_replace('/[^a-zA-Z0-9]/', ' ', substr($item->getName(), 0,30));
					$i++;
				}	
			}
			
			$blueAddress = $this->scopeConfig->getValue('bluedart/general/store_address');
			$bluedartKey = $this->scopeConfig->getValue('bluedart/general/licence_key');
			$loginId = $this->scopeConfig->getValue('bluedart/general/login_id');
			$storeName = $this->scopeConfig->getValue('bluedart/general/store_name');
			$email = $this->scopeConfig->getValue('bluedart/general/email');
			$storePhone = $this->scopeConfig->getValue('bluedart/general/telephone');
			$storePincode = $this->scopeConfig->getValue('bluedart/general/pincode');
			$customercode = $this->scopeConfig->getValue('bluedart/general/customer_code');
			$vandercode = $this->scopeConfig->getValue('bluedart/general/vender_code');
			$originarea = $this->scopeConfig->getValue('bluedart/general/origin_area');
			$gst_no = $this->scopeConfig->getValue('bluedart/general/tin_no');
					
			$dimension_breadth = isset($param['shipment']['breadth']) ? $param['shipment']['breadth'] : 1;
			$dimension_height = isset($param['shipment']['height']) ? $param['shipment']['height'] : 1;
			$dimension_length = isset($param['shipment']['length']) ? $param['shipment']['length'] : 1;
					
			$dimension = $dimension_length.'*'.$dimension_breadth.'*'.$dimension_height;
					
			if($collectableAmount) {
				$mrp = $collectableAmount;
			}
			
			$cust_street = $shipping_address->getStreet();

			$cust_street = (isset($cust_street[1])) ? $cust_street[0].', '.$cust_street[1].', '.$shipping_address->getCity() : $cust_street[0].', '.$shipping_address->getCity();

			$cust_street = ($shipping_address->getCompany()) ? $shipping_address->getCompany().', '.$cust_street : 	$cust_street;	

			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$country = $objectManager->create('\Magento\Directory\Model\Country')->load($shipping_address->getCountry());
			// $country = $this->_countryFactory->create()->loadByCode($shipping_address->getCountry());
			$cust_resion = $shipping_address->getRegion().', '.$country->getName();
			$cust_pin = $shipping_address->getPostcode();
			$cust_phone = $shipping_address->getTelephone();

			$line_store_address = explode("\n",$blueAddress);
			$oneLine_address = '';
			foreach($line_store_address as $add)
			{
				$address .= '<p>'.$add.'</p>';
				$oneLine_address .= $add;
			}

			$html_2 = '';
			if(
				($payment_method_code == 'phoenix_cashondelivery') || 
				($payment_method_code == 'cashondelivery') || 
				($payment_method_code == 'msp_cashondelivery')
			) {
				$html_2 = '<div class="ttl-amnt"><h2>AMOUNT TO BE COLLECTED <br> Rs. '.$collectableAmount.'</h2></div>';
			}

			$html_3 = '<table width="100%" cellspacing="0" cellpadding="8"><tr>
				<td align="center" valign="middle" style="width: 6%;">Sr.</td>
				<td align="center" valign="middle" style="width: 10%;">Item Code</td>
				<td align="center" valign="middle" style="width: 30%;">Item Description</td>
				<td align="center" valign="middle" style="width: 12%;">Quantity</td>
				<td align="center" valign="middle" style="width: 12%;">Value</td>
				<td align="center" valign="middle" style="width: 12%;">Total Amount</td>
			</tr>';
			$j = 1;

			foreach($ordered_items as $item)
			{
				if(!$item->getParentItemId())
				{
					$sku = $item->getSku();
					$p_name = $item->getName();
					$p_qty = number_format($item->getQtyOrdered(),2);
					$p_baseprice = number_format($item->getBasePrice(),2);
					$p_price = number_format($item->getPrice(),2);
					$final_price =  number_format((($item->getQtyOrdered()) * ($item->getPrice())),2);

					$html_3 .= '<tr>
						<td align="center" valign="middle" style="width: 6%;">'.$j.'</td>
						<td align="center" valign="middle" style="width: 10%;">'.$sku.'</td>
						<td align="center" valign="middle" style="width: 30%;">'.$p_name.'</td>
						<td align="center" valign="middle" style="width: 12%;">'.$p_qty.'</td>
						<td align="center" valign="middle" style="width: 12%;">'.$p_price.'</td>
						<td align="center" valign="middle" style="width: 12%;">'.$final_price.'</td>
					</tr>';
					$j++;
				}
			}

			$grand_total = number_format($order->getGrandTotal(),2);
			$ship_changes = number_format($order->getShippingAmount(),2);
			$tax_amt = number_format($order->getTaxAmount(),2);

			$discount_amt = number_format($order->getDiscountAmount(),2);
			$dis_html = '';
			if($discount_amt)
			{
				$dis_html = '<tr>
								<td colspan="3" align="center" valign="middle" style="width: 46%;"></td>
								<td colspan="2" align="center" valign="middle" style="width: 24%;">'.__('Discount (%s)', $order->getDiscountDescription()).'</td>
								<td align="center" valign="middle" style="width: 12%;">'.$discount_amt.'</td>
							</tr>';
			}

			$html_3 .= '<tr>
					<td colspan="3" align="center" valign="middle" style="width: 46%;"></td>
					<td colspan="2" align="center" valign="middle" style="width: 24%;">Shipping Charges</td>
					<td align="center" valign="middle" style="width: 12%;">'.$ship_changes.'</td>
				</tr>
				<tr>
					<td colspan="3" align="center" valign="middle" style="width: 46%;"></td>
					<td colspan="2" align="center" valign="middle" style="width: 24%;">Tax Charges</td>
					<td align="center" valign="middle" style="width: 12%;">'.$tax_amt.'</td>
				</tr>
				'.$dis_html.'
				<tr>
					<td colspan="3" align="center" valign="middle" style="width: 46%;"></td>
					<td colspan="2" align="center" valign="middle" style="width: 24%;">Total</td>
					<td align="center" valign="middle" style="width: 12%;">'.$grand_total.'</td>
				</tr>
			</table>';

			$invIncrementIDs = '';
			if ($order->hasInvoices()) {
				$invIncrementIDs = array();
				foreach ($order->getInvoiceCollection() as $inv) {
					$invIncrementIDs = $inv->getIncrementId();
					$invDate = date('d-M-Y',strtotime($inv->getCreatedAt()));
				}
			}
			/*$mediapath = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)
											->getAbsolutePath('bluedart/logo');*/
			$mediaUrl = $this->_storeManager
                     			->getStore()
                     			->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

			$logoUrl = $mediaUrl.'bluedart/logo/'.$this->scopeConfig->getValue('bluedart/general/pdf_logo');

			$html = '<html><head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><title></title>
				<meta name="description" content=""></head><body>
				<div class="main-block">
				<div class="sectn-top">
				<div class="log-main">
				<img alt="logo" src="'.$logoUrl.'" />
				</div>
				<div class="ship-adrs">
				<h2>'.$storeName.'</h2>'.$address.'<p>PIN : '.$storePincode.'</p>
				<p>Phone : '.$storePhone.'</p>
				<p>Email : '.$email.'</p>
				</div>
				<div class="inv-dtails">
				<p><h4>GST NO : '.$gst_no.'</h4></p>
				</div></div>
				<div class="sectn-mid">
				<div class="ship-adrs border-no">
				<h2>DELIVER TO</h2>
				<p>'.$cust_name.'<br>'.$cust_street.'</p>
				<p>'.$cust_resion.'</p>
				<h2>'.$cust_pin.' - '.$des_area.'/'.$des_loc.'</h2>
				<p>Phone '.$cust_phone.'</p>
				</div>
				<div class="ordr-dtails">
				<div class="o-id">
				<h2>ORDER ID</h2>
				<div class="img-cntr"><barcode code='.$order_id.' type="C39" size="1.0" height="2.0" /></div>
				<p style="text-align: center;">'.$order_id.'</p>
				</div>
				<div class="o-id o-cod">
				<h2>'.$pdf_method.'</h2>
				<div class="img-cntr"><barcode code='.$AWB_No.' type="C39" size="1.0" height="2.0" /></div>
				<p style="text-align: center;">'.$AWB_No.'</p>
				</div>
				<div class="p-details">
				<p>AWB No. <span>: '.$AWB_No.'</span></p>
				<p>Weight (kgs) <span>: '.$weight.'</span></p>
				<p>Dimensions (cms) <span>: '.$dimension.'</span></p>
				<p>Order ID <span>: '.$order_id.'</span></p>
				<p>Order Date <span>: '.$order_date.'</span></p>
				<p>Pieces <span>: '.$qty.'</span></p> 
				</div>
				</div>
				'.$html_2.'
				</div>
				<div class="tble-btm">'.$html_3.'</div>
				<p style="width: 100%; text-align:center; font-size: 16px; margin-bottom: 5px;">This is computer generated document, hence does not require signature.</p>
				<table class="botm-adrss" cellspacing="0" cellpadding="5" border="0">
				<tr>
				<td style="width: 150px" valign="top"><p style="font-size: 18px; font-weight:600; margin:0">Return Address :</p></td>
				<td style="width: 800px" valign="top"><p style="font-size: 16px; font-weight:normal; margin:0 0 0 15px">'.$storeName.', '.$oneLine_address.','.$storePincode.'</p></td>
				</tr></table></div></body></html>'; //Assign HTML HERE
		} catch (\Exception $e) {
			die($e->getMessage());
		}
		// echo file_put_contents('/var/www/html/forestessentialsm2/pdf.html', $html);
		// echo "<pre>"; print_r($html); echo "</pre>";
		// die();

		return $html;
	}
}