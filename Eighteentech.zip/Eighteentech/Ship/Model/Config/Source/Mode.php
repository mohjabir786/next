<?php

namespace Eighteentech\Ship\Model\Config\Source;

class Mode implements \Magento\Framework\Data\OptionSourceInterface
{
	
	public function toOptionArray()
	{
        $this->_options = [
        	['label' => 'Sandbox', 'value' => '1'],
        	['label' => 'Live', 'value' => '2']
        ];
        return $this->_options;
    }
}