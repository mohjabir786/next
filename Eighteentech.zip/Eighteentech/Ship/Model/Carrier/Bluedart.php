<?php
namespace Eighteentech\Ship\Model\Carrier;

use Magento\Quote\Model\Quote\Address\RateRequest;

class Bluedart extends \Magento\Shipping\Model\Carrier\AbstractCarrier implements
    \Magento\Shipping\Model\Carrier\CarrierInterface
{
    /**
     * @var string
     */
    protected $_code = 'bluedart';
	
	protected $_logger;
    /**
     * @var bool
     */
    protected $_isFixed = true;

    /**
     * @var \Magento\Shipping\Model\Rate\ResultFactory
     */
    protected $_rateResultFactory;


    /**
     * @var \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory
     */
    protected $_rateMethodFactory;

    protected $_messageManager;

    protected $orderModel;

    protected $shipmentFactory;

    protected $_shipmentTrackFactory;

    protected $productRepository;

    protected $scopeConfig;

    /**
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Shipping\Model\Rate\ResultFactory $rateResultFactory
     * @param \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Shipping\Model\Rate\ResultFactory $rateResultFactory,
        \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory,
        \Magento\Shipping\Model\Tracking\ResultFactory $trackFactory,
        \Magento\Shipping\Model\Tracking\Result\ErrorFactory $trackErrorFactory,
        \Magento\Shipping\Model\Tracking\Result\StatusFactory $trackStatusFactory,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Sales\Model\Service\InvoiceService $invoiceService,
        \Magento\Framework\DB\Transaction $transaction,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Sales\Model\Convert\Order $orderModel,
        \Magento\Sales\Model\Order\Shipment\TrackFactory $_shipmentTrackFactory,
        \Magento\Shipping\Model\ShipmentNotifier $shipmentFactory,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Sales\Model\Order\Email\Sender\InvoiceSender $invoiceSender,
        array $data = []
    ) {
        $this->_rateResultFactory = $rateResultFactory;
        $this->_rateMethodFactory = $rateMethodFactory;
		$this->_logger = $logger;
        $this->_orderRepository = $orderRepository;
        $this->_invoiceService = $invoiceService;
        $this->_transaction = $transaction;
        $this->_messageManager = $messageManager;
        $this->orderModel = $orderModel;
        $this->_shipmentTrackFactory = $_shipmentTrackFactory;
        $this->shipmentFactory = $shipmentFactory;
        $this->productRepository = $productRepository;
        $this->_trackFactory = $trackFactory;
        $this->_trackErrorFactory = $trackErrorFactory;
        $this->_trackStatusFactory = $trackStatusFactory;
        $this->invoiceSender = $invoiceSender;
        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
    }

    /**
     * @param RateRequest $request
     * @return \Magento\Shipping\Model\Rate\Result|bool
     */
    public function collectRates(RateRequest $request)
    {
        if (!$this->getConfigFlag('active')) {
            return false;
        }

        /** @var \Magento\Shipping\Model\Rate\Result $result */
        $result = $this->_rateResultFactory->create();
		
		$shippingPrice = $this->getConfigData('price');
		$method = $this->_rateMethodFactory->create();
		$method->setCarrier($this->_code);
		$method->setCarrierTitle($this->getConfigData('title'));
		$method->setMethod($this->_code);
		$method->setMethodTitle($this->getConfigData('name'));
		$method->setPrice($shippingPrice);
		$method->setCost($shippingPrice);
		$result->append($method);
        

        return $result;
    }

    /**
     * @return array
     */
    public function getAllowedMethods()
    {
		
        return [$this->_code=> $this->getConfigData('name')];
    }

    public function isTrackingAvailable() 
    { 
        return true;
    }

    public function getTrackingInfo($tracking)
    {
        //$track = Mage::getModel('shipping/tracking_result_status');
        $track = $this->_trackStatusFactory->create();
        $track->setUrl('http://www.bluedart.com/htotrack.html?numbers=' . $tracking)
              ->setTracking($tracking)
              ->setCarrierTitle($this->getConfigData('title'));
        return $track;
    }

    /**
     *  Generate Invoice
     */

    private function generateInvoice($orderId)
    {
        try {
            $order = $this->_orderRepository->get($orderId);
            if($order->canInvoice()) 
            {
                $invoice = $this->_invoiceService->prepareInvoice($order);
                $invoice->register();
                $invoice->save();
                $transactionSave = $this->_transaction->addObject(
                    $invoice
                )->addObject(
                    $invoice->getOrder()
                );
                $transactionSave->save();
                $this->invoiceSender->send($invoice);
                //send notification code
                $order->addStatusHistoryComment(
                    __('Notified customer about invoice #%1.', $invoice->getId())
                )
                ->setIsCustomerNotified(true)
                ->save();
            }
        } catch (\Exception $e) {
            $this->_messageManager->addError(__('Order %s Error in Invoice ', $order->getIncrementId()));
        } 
    }

    /**
     *  Generate Bluedart AWB
     */

    public function _bdcodawb($orderId){
        $order = $this->_orderRepository->get($orderId);
        $store_id = "";
        $hasinvoice = $order->hasInvoices();
        if(!$hasinvoice)
            $this->generateInvoice($orderId);
        $awbinfo = $this->getGeneratewaybillAction($orderId);
        return $awbinfo;
    }

    public function getGeneratewaybillAction($orderId)
    {
        $store_id = "";
        $order = $this->_orderRepository->get($orderId);
        $gendetails = [];
        $waybillgenerationurl = "http://netconnect.bluedart.com/Ver1.8/ShippingAPI/WayBill/WayBillGeneration.svc";
        $soap = new \SoapClient($waybillgenerationurl.'?wsdl',
                array(
                'trace'               => 1,  
                'style'               => SOAP_DOCUMENT,
                'use'                 => SOAP_LITERAL,
                'soap_version'        => SOAP_1_2
                ));

        $soap->__setLocation($waybillgenerationurl);
                
        $soap->sendRequest = true;
        $soap->printRequest = false;
        $soap->formatXML = true; 
                
        $actionHeader = new \SoapHeader('http://www.w3.org/2005/08/addressing','Action','http://tempuri.org/IWayBillGeneration/GenerateWayBill',true);
        $soap->__setSoapHeaders($actionHeader); 
                #echo "end of Soap 1.2 version (WSHttpBinding)  setting";
        
        $params = $this->getParams($orderId);
        // echo "<pre>"; print_r($params); echo "</pre>";
        try {
            $result = $soap->__soapCall('GenerateWayBill',array($params));
            // echo "<pre>+++++"; print_r($result); echo "</pre>";
            // die();

            $data = $result->GenerateWayBillResult->AWBPrintContent;
            $error = $result->GenerateWayBillResult->IsError;

            if(!empty($error)) {
                $check_err = $result->GenerateWayBillResult->Status->WayBillGenerationStatus;//->StatusInformation ;
                if(is_array($check_err)) {
                    $k=1;
                    $error_msg = '';
                    foreach($check_err as $err) {
                        if($k==1)
                            $error_msg = $k.')-'.$err->StatusInformation;
                        else    
                            $error_msg = $error_msg.'. '.$k.')-'.$err->StatusInformation;   
                        $k++;   
                    }
                }
                else
                    $error_msg = $result->GenerateWayBillResult->Status->WayBillGenerationStatus->StatusInformation ;
                
                $this->_messageManager->addError($error_msg);
            }else {     // Print AWB
                //print_r($result);
                //$params["Request"]["Shipper"]["CustomerCode"]                 
                $this->_messageManager->addSuccess($order->getIncrementId()." -> ".$result->GenerateWayBillResult->AWBNo);
                $gendetails = array(
                    'AWB_No' => $result->GenerateWayBillResult->AWBNo,
                    'des_area' => $result->GenerateWayBillResult->DestinationArea, 
                    'des_loc' => $result->GenerateWayBillResult->DestinationLocation,
                    'cust_code' => "BLUEDART ".$params["Request"]["Shipper"]["CustomerCode"]." ".$this->currentmode
                );
                $awbno = $result->GenerateWayBillResult->AWBNo;
                if($awbno){
                    $this->insertAwbDetails($awbno, $orderId);
                }

                if($result->GenerateWayBillResult->AWBPrintContent) {
                  $awb_pdf =  $result->GenerateWayBillResult->AWBPrintContent;
                }

                if($awb_pdf != "") {
                    $this->generatepdf($awb_pdf,$awbno);
                    $awfile = BP."/var/bluedart/".$awbno.".pdf";
                    if (file_exists($awfile)) {
                        $this->_messageManager->addSuccess('AWB Pdf generated succesfully.');
                    } else {
                        $this->_messageManager->addError("AWB Pdf not generated. Please check the permission for var/bluedart/ folder.");
                    }
                }
            }
        }catch(Exception $ee){
            $this->_messageManager->addError($ee->getMessage());
        }

        return $gendetails;
    }

    private function insertAwbDetails($awbno, $orderId)
    {
        $order = $this->_orderRepository->get($orderId);
        if($order->canShip()) { 
            try {
                $shipment = $this->orderModel->toShipment($order);
                foreach ($order->getAllItems() as $orderItem)
                {
                    if (!$orderItem->getQtyToShip() || $orderItem->getIsVirtual()) {
                        continue;
                    }
                    $qtyShipped = $orderItem->getQtyToShip();
             
                    $shipmentItem = $this->orderModel->itemToShipmentItem($orderItem)->setQty($qtyShipped);
             
                    $shipment->addItem($shipmentItem);
                }
             
                $shipment->register();
                $shipment->getOrder()->setIsInProcess(true);
             
                try {
                    $trackingIds = [
                        '0' => [
                            'carrier_code' => 'bluedart',
                            'title' => 'Blue Dart',
                            'number' => $awbno
                        ]
                    ];
             
                    /*Add Multiple tracking information*/
                    foreach ($trackingIds as $trackingId) {
                        $data = array(
                            'carrier_code' => $trackingId['carrier_code'],
                            'title' => $trackingId['title'],
                            'number' => $trackingId['number'],
                        );
                        $track = $this->_shipmentTrackFactory->create()->addData($data);
                        $shipment->addTrack($track)->save();
                    }
             
                    $shipment->save();
                    $shipment->getOrder()->save();
             
                    // Send email
                    $this->shipmentFactory->notify($shipment);
                    $shipment->save();

                } catch (\Exception $e) {
                    $this->_messageManager->addError(__("Shipment save error"));
                }   
            } catch (\Exception $e) {
                $this->_messageManager->addError(__($e->getMessage()));
            }
        }
    }

    private function generatepdf($awb_pdf,$awbno)
    {
        $filename = BP.'/var/bluedart/'.$awbno.".pdf";
        $file = fopen($filename,"w+");
        fwrite($file,$awb_pdf);
        fclose($file);
    }

    private function getParams($orderId)
    {
        $store_id = "";
        $order = $this->_orderRepository->get($orderId);
        $shipping_mode = ""; 
        $shipping_address = $order->getShippingAddress(); 
        
        $cust_name = $shipping_address->getFirstname().' '.$shipping_address->getLastname();

        $payment_method_code = $order->getPayment()->getMethodInstance()->getCode(); //cashondelivery
        $collectableAmount = '';

        $SubProductCode = 'p';
        $pdf_method = "PREPAID ORDER";
        if(($payment_method_code == 'phoenix_cashondelivery') || ($payment_method_code == 'cashondelivery')|| ($payment_method_code == 'msp_cashondelivery'))
        {
            $shipping_mode = "COD";
            $collectableAmount = $order->getGrandTotal(); 
            $SubProductCode = 'c';
            $pdf_method = "CASH ON DELIVERY (COD)"; 
        }
        $this->currentmode = $shipping_mode;
        $ordered_items = $order->getAllItems(); 
        $mrp = 0;
        $commodityDetail = array();
        $i = 1;
        $qty = 0;
        $weight = 0;
        foreach($ordered_items as $item)
        {    
            if(!$item->getParentItemId())
            {   
                $item->getItemId(); //product id     
                $item->getSku();
                $product = $this->productRepository->get($item->getSku());
                $qty = $qty + $item->getQtyOrdered(); //ordered qty of item     
                $mrp = $mrp + $item->getprice(); 
                $weight += ($product->getWeight() * $item->getQtyOrdered())/1000 ; 
                $commodityDetail['CommodityDetail'.$i] =  preg_replace('/[^a-zA-Z0-9]/', ' ', substr($item->getName(), 0,30));
                $i++;
             }  
        }   
        if($weight < 0.05) {
            $weight = 0.05; 
        }

        $bluedartKey = $this->_scopeConfig->getValue('bluedart/general/licence_key');
        $loginId = $this->_scopeConfig->getValue('bluedart/general/login_id');

        $dimension_breadth = 1;
        $dimension_height = 1;
        $dimension_length = 1;
        
        $dimension = $dimension_length.'*'.$dimension_breadth.'*'.$dimension_height;
        if($collectableAmount) {
            $mrp = $collectableAmount;
        }

        $street = $shipping_address->getStreet();
        if (!empty($street)) {
            $street_0 = isset($street[0]) ? $street[0] : '';
            $street_1 = isset($street[1]) ? $street[1] : '';
            $street_length = strlen($street_0.$street_1); 
            $consignee_adress1 = substr($street_0, 0, 30); 
            $consignee_adress2 = substr($street_0.$street_1, 30, 30);
            $consignee_adress3 = substr($street_0.$street_1, 60, 30);
        } else {
            $street_length = ''; 
            $consignee_adress1 = ''; 
            $consignee_adress2 = '';
            $consignee_adress3 = '';
        }
        
        //$consignee_adress3 = substr($street[0].$street[1], 60, $street_length);


        $invIncrementIDs = array();
        if ($order->hasInvoices()) {
            foreach ($order->getInvoiceCollection() as $inv) {
                $invIncrementIDs[] = $inv->getIncrementId();
            }
        }

        $params = [
            'Request' => [
                'Consignee' => [
                    'ConsigneeAddress1' => $consignee_adress1,
                    'ConsigneeAddress2' => $consignee_adress2,
                    'ConsigneeAddress3'=>  $consignee_adress3,
                    'ConsigneeAttention'=> '',
                    'ConsigneeMobile'=> $shipping_address->getTelephone(),
                    'ConsigneeName'=> $cust_name,
                    'ConsigneePincode'=> $shipping_address->getPostcode(),
                    'ConsigneeTelephone'=> $shipping_address->getTelephone(),
                ],
                'Services' => [
                    'ActualWeight' => $weight,
                    'CollectableAmount' => $collectableAmount,
                    'Commodity' =>$commodityDetail,
                    'CreditReferenceNo' => $store_id.$order->getIncrementId(),
                    'DeclaredValue' => $mrp,
                    'Dimensions' => [
                        'Dimension' => [
                                'Breadth' => $dimension_breadth,
                                'Count' => '',
                                'Height' => $dimension_height,
                                'Length' => $dimension_length
                            ],
                        ],
                        'InvoiceNo' => $invIncrementIDs[0],
                        'PackType' => '',
                        'PickupDate' => date('Y-m-d'),
                        'PickupTime' => '1800',//(optional)
                        'PieceCount' => '1',//(#default)
                        'ProductCode' => 'A',//(#default)
                        'ProductType' => 'Dutiables',//(#default)
                        'SpecialInstruction' => '',
                        'SubProductCode' => $SubProductCode,//(for prepaid ordered it will p & #for COD it will be c)
                    ],
                    'Shipper' => $this->getClientinfo(),
                    'SubShipper' => $this->getClientinfo()
                ],
            'Profile' => [
                'Api_type' => 'S',
                'LicenceKey'=> $bluedartKey,
                'LoginID'=> $loginId,
                'Version'=> '1.3'
            ]
        ];
        return $params;
    }
    
    private function getClientinfo()
    {
        $blueAddress = $this->_scopeConfig->getValue('bluedart/general/store_address');
        $line_store_address = explode("\n",$blueAddress);

        $bluedartKey = $this->_scopeConfig->getValue('bluedart/general/licence_key');
        $loginId = $this->_scopeConfig->getValue('bluedart/general/login_id');
                        
        $storeName = $this->_scopeConfig->getValue('bluedart/general/store_name');
        $email = $this->_scopeConfig->getValue('bluedart/general/email');
        $storePhone = $this->_scopeConfig->getValue('bluedart/general/telephone');
        $storePincode = $this->_scopeConfig->getValue('bluedart/general/pincode');
        $customercode = $this->_scopeConfig->getValue('bluedart/general/customer_code');
        $vandercode = $this->_scopeConfig->getValue('bluedart/general/vender_code');
        $originarea = $this->_scopeConfig->getValue('bluedart/general/origin_area');
        $gst_no = $this->_scopeConfig->getValue('bluedart/general/tin_no');

        return [
            'CustomerAddress1' => isset($line_store_address[0]) ? $line_store_address[0] : '',
            'CustomerAddress2' => isset($line_store_address[1]) ? $line_store_address[1] : '',
            'CustomerAddress3' => isset($line_store_address[2]) ? $line_store_address[2] : '',
            'CustomerAddress4' => isset($line_store_address[3]) ? $line_store_address[3] : '',
            'CustomerAddress5' => isset($line_store_address[4]) ? $line_store_address[4] : '',
            'CustomerCode' => $customercode,
            'CustomerEmailID' => $email,
            'CustomerMobile' => $storePhone,
            'CustomerName' => $storeName,
            'CustomerPincode' => $storePincode,
            'CustomerTelephone' => $storePhone,
            'IsToPayCustomer' => false,
            'OriginArea' => $originarea,
            'Sender' => '',
            'VendorCode' => $vandercode,
            'Vendor' => $vandercode
        ];
    }
}