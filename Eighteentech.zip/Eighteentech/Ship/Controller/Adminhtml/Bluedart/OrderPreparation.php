<?php
namespace Eighteentech\Ship\Controller\Adminhtml\Bluedart;

use \Mpdf\Mpdf;

class OrderPreparation extends \Magento\Backend\App\Action
{
	protected $_messageManager;
	protected $_assetRepo;
	protected $_bluedartModel;
	protected $_bluedartHelper;

	public function __construct(
		\Magento\Backend\App\Action\Context $context,
	    \Magento\Framework\Message\ManagerInterface $messageManager,
	    \Magento\Framework\View\Asset\Repository $assetRepo,
	    \Eighteentech\Ship\Model\Carrier\Bluedart $blueDartModel,
	    \Eighteentech\Ship\Helper\Data $bluedartHelper
	) {
		$this->_messageManager = $messageManager;
		$this->_assetRepo = $assetRepo;
		$this->_bluedartModel = $blueDartModel;
		$this->_bluedartHelper = $bluedartHelper;
	    parent::__construct($context);
	}

	public function execute()
    {
    	// $mpdf = new Mpdf();
    	// $mpdf = new Mpdf(['mode' => 'utf-8', 'format' => 'A4-L']);
    	// $mpdf=new mPDF('c','B3','','',32,25,27,25,16,13); 
    	//$mpdf = new Mpdf(['mode' => '', 'format' => 'A4', 'orientation' => 'P']);
    	$mpdf = new Mpdf(array('mode' => 'utf-8', 'format' => 'B3', 0, '', 15, 15, 16, 16, 9, 9, 'orientation' => 'P'));
    	$cssPath = $this->_assetRepo->getUrl("Eighteentech_Ship::css/pdf.css");
    	$mpdf->SetDisplayMode('fullpage');

		$stylesheet = file_get_contents($cssPath); 					  
		$mpdf->WriteHTML($stylesheet,1);
		$flag = false;
		
        $generateorderIds = $this->getRequest()->getParam('selected');

        if(!is_array($generateorderIds))
        {
			$this->_messageManager->addError(__('Please select item(s)'));
        } else {
        	try {
        		$i = 0;
        		foreach ($generateorderIds as $generateorderId) {
        			//$this->_bdcodawb($generateorderId);
					$flag = true;
					$bluedartShipping = $this->_bluedartModel->_bdcodawb($generateorderId);

					if (!empty($bluedartShipping) && !empty($bluedartShipping['AWB_No']))
					{
						$html = $this->_bluedartHelper->getHtml($generateorderId,$bluedartShipping["AWB_No"],$bluedartShipping["des_area"],$bluedartShipping["des_loc"],
								$bluedartShipping["cust_code"]);
						$mpdf->WriteHTML($html,2);
						if((count($generateorderIds)-$i) > 1) {
							$mpdf->AddPage();
						}
					}
					
					$i++;
				}
	            $this->_messageManager->addSuccess(__('Total of %1 record(s) were successfully', count($generateorderIds)));
        	} catch (\Exception $e) {
        		$this->_messageManager->addError(__($e->getMessage()));
        	}
        }

        $file_name = 'order_blue_'.date('d-M-Y-h-m-s').'.pdf';
        $filename = BP."/var/bluedart/".$file_name ;
        $dirPath = BP."/var/bluedart/";
		if (!file_exists($dirPath)) {
		    mkdir($dirPath, 0777);
		}

		if (!file_exists($filename)) {
			$mpdf->Output($filename,'F');
			$mpdf->Output($filename,'D');
		}
		// $mpdf->Output($filename,'D');
		// die('___hello');

		if ($flag) {
			$this->_messageManager->addSuccess($filename);
        } else {
            $this->_messageManager->addError(__('There are no printable documents related to selected orders'));
		}
		$this->_redirect('sales/order/index');
		// die();
    }
}