<?php
namespace Eighteentech\Restrictcod\Controller\Checkzipcode;

use \Magento\Framework\App\Action\Action;

class Index extends Action
{
    
    protected $resultPageFactory;

    protected $helperData;
    protected  $paymethods;
    protected $resultJsonFactory; 
    
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Eighteentech\Restrictcod\Helper\Data $helperData,
        \Eighteentech\Restrictcod\Block\Adminhtml\Restrictcod\Edit\Tab\Main $paymethods,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
        )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->helperData = $helperData;
        $this->paymethods =$paymethods;
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }

    
    public function execute()
    {
        if ($this->getRequest()->getPostValue()) {
            try {

                $post_data = $this->getRequest()->getPostValue();
                $inputFilter = new \Zend_Filter_Input(
                    [],
                    [],
                    $post_data
                );
                
                $post_data = $inputFilter->getUnescaped();
                $model =$this->_objectManager->create('Eighteentech\Restrictcod\Model\Restrictcod')->getCollection();
                $zipCode = $model->addFieldToFilter('zipcode',$post_data['zipcode'])->getFirstItem();
                if(count($zipCode->getData())){
                    $zipCodeData = $zipCode->getData();    
                    $restrictPaymentMethods = explode(',',$zipCodeData['restricted_paymentmethods']);
                    $activePaymentMethodCustom=[];
                    $activePaymentMethods=$this->paymethods->toOptionArray();
                    $checkAvailability="";
                    $cashondelivery="";
                    $activePaymentMethodDataChk="";
                    foreach($activePaymentMethods as $activePaymentMethod){
							$activePaymentMethodCustom[]=$activePaymentMethod['value'];
					}
					$activePaymentMethodData=$activePaymentMethodCustom;
                    if(empty($restrictPaymentMethods)){
						$checkAvailability= $this->helperData->getAvailabliltyArea();
						if(in_array('cashondelivery',$activePaymentMethodData)){
							$cashondeliveryMsg = $this->helperData->getSuccessMsg();
                            $coderror=false;
						}else{
							$cashondeliveryMsg = $this->helperData->getErrorMsg();
                            $coderror=true;
						}
					}else{
						if(!in_array('cashondelivery',$restrictPaymentMethods)){
							$cashondeliveryMsg = $this->helperData->getSuccessMsg();
                            $coderror=false;
						}else{
							$cashondeliveryMsg = $this->helperData->getErrorMsg();
                            $coderror=true;
						}
						 $checkAvailabilityMsg = $this->helperData->getNotAvailabliltyArea();
                         $availerror = true;							
						 foreach($activePaymentMethodData as $activePaymentMethodDataChk){
							if(!in_array($activePaymentMethodDataChk,$restrictPaymentMethods)){
								$checkAvailabilityMsg = $this->helperData->getAvailabliltyArea();
                                $availerror = false;
							}
						 }

					}
                    //$vars = array('{est_days}'=>$zipCodeData['estimated_days']);
                    //$delivery_day_msg = strtr($this->helperData->getDeliveryDaysMsg(),$vars);
                    //$success_msg = $this->helperData->getSuccessMsg();
                    $response = array('availmsg'=>$checkAvailabilityMsg,'codmsg'=>$cashondeliveryMsg,'availerror'=>$availerror,'coderror'=>$coderror);
                }else{
                    $error_msg = $this->helperData->getNotAvailabliltyArea();
                    $response = array('availmsg'=>$error_msg,'availerror'=>true);
                }
                return $this->resultJsonFactory->create()->setData($response);
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $response = array('msg'=>$e->getMessage(),'error'=>true);
                return $this->resultJsonFactory->create()->setData($response);
            } catch (\Exception $e) {
                $response = array('msg'=>__('Something went wrong while getting data. Please review the error log.'),'error'=>true);
                $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
                return $this->resultJsonFactory->create()->setData($response);
            }

        }
    }
}
