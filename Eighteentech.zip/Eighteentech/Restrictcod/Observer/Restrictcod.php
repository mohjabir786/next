<?php
namespace Eighteentech\Restrictcod\Observer;

use Magento\Framework\Event\ObserverInterface;

class Restrictcod implements ObserverInterface 
{
    protected $_checkoutSession;

    protected $_objectManager;

    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\ObjectManagerInterface $objectManager
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->_objectManager = $objectManager;
    }
    public function execute(\Magento\Framework\Event\Observer $observer) {

        $method = $observer->getEvent()->getMethodInstance();
        $result = $observer->getEvent()->getResult();
        $zipcode = $this->_checkoutSession->getQuote()->getShippingAddress()->getPostcode();
        if($zipcode){
            $zipCode = $this->_objectManager->create('Eighteentech\Restrictcod\Model\Restrictcod')->getCollection()->addFieldToFilter('zipcode',$zipcode)->getFirstItem();
            $restrictedPaymentMethods = explode(',',$zipCode->getData('restricted_paymentmethods'));
                if(count($zipCode->getData())>0){
					if(in_array($method->getCode(),$restrictedPaymentMethods)){
						return $result->setData('is_available', false);
					}
                }else{
					if(in_array($method->getCode(),$restrictedPaymentMethods)){
						return $result->setData('is_available', true);
					}
                }
        }
    }
}
