<?php
namespace Eighteentech\Restrictcod\Block\Adminhtml\Restrictcod;

class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{
    /**
     * @var \Magento\Framework\Module\Manager
     */
    protected $moduleManager;

    /**
     * @var \Eighteentech\Restrictcod\Model\restrictcodFactory
     */
    protected $_restrictcodFactory;

    /**
     * @var \Eighteentech\Restrictcod\Model\Status
     */
    protected $_status;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Eighteentech\Restrictcod\Model\restrictcodFactory $restrictcodFactory
     * @param \Eighteentech\Restrictcod\Model\Status $status
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param array $data
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Eighteentech\Restrictcod\Model\RestrictcodFactory $RestrictcodFactory,
        \Eighteentech\Restrictcod\Model\Status $status,
        \Magento\Framework\Module\Manager $moduleManager,
        array $data = []
    ) {
        $this->_restrictcodFactory = $RestrictcodFactory;
        $this->_status = $status;
        $this->moduleManager = $moduleManager;
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('postGrid');
        $this->setDefaultSort('id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(false);
        $this->setVarNameFilter('post_filter');
    }

    /**
     * @return $this
     */
    protected function _prepareCollection()
    {
        $collection = $this->_restrictcodFactory->create()->getCollection();
        $this->setCollection($collection);

        parent::_prepareCollection();

        return $this;
    }

    /**
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareColumns()
    {
        $this->addColumn(
            'id',
            [
                'header' => __('ID'),
                'type' => 'number',
                'index' => 'id',
                'header_css_class' => 'col-id',
                'column_css_class' => 'col-id'
            ]
        );

		$this->addColumn(
			'zipcode',
			[
				'header' => __('Zip Code'),
				'index' => 'zipcode',
			]
		);

        $this->addColumn(
            'product_availability',
            [
                'header' => __('Product Availability'),
                'index' => 'product_availability',
                'filter' => false,
                'sortable' => false,
                'renderer'  => 'Eighteentech\Restrictcod\Block\Adminhtml\Restrictcod\Renderer\ProductAvailability'
            ]
        );
		
        $this->addColumn(
            'cod_availability',
            [
                'header' => __('COD Availability'),
                'index' => 'cod_availability',
                'filter' => false,
                'sortable' => false,
                'renderer'  => 'Eighteentech\Restrictcod\Block\Adminhtml\Restrictcod\Renderer\CodAvailability'
            ]
        ); 
		/*$this->addColumn(
			'estimated_days',
			[
				'header' => __('Estimated Delivery Days'),
				'index' => 'estimated_days',
			]
		);*/

        $this->addColumn(
            'edit',
            [
                'header' => __('Edit'),
                'type' => 'action',
                'getter' => 'getId',
                'actions' => [
                    [
                        'caption' => __('Edit'),
                        'url' => [
                            'base' => '*/*/edit'
                        ],
                        'field' => 'id'
                    ]
                ],
                'filter' => false,
                'sortable' => false,
                'index' => 'stores',
                'header_css_class' => 'col-action',
                'column_css_class' => 'col-action'
            ]
        );
		
		$this->addExportType($this->getUrl('restrictcod/*/exportCsv', ['_current' => true]),__('CSV'));

        $block = $this->getLayout()->getBlock('grid.bottom.links');
        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }

        return parent::_prepareColumns();
    }

	
    /**
     * @return $this
     */
    protected function _prepareMassaction()
    {

        $this->setMassactionIdField('id');

        $this->getMassactionBlock()->setFormFieldName('restrictcod');

        $this->getMassactionBlock()->addItem(
            'delete',
            [
                'label' => __('Delete'),
                'url' => $this->getUrl('restrictcod/*/massDelete'),
                'confirm' => __('Are you sure?')
            ]
        );


        return $this;
    }
		

    /**
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('restrictcod/*/index', ['_current' => true]);
    }

    /**
     * @param \Eighteentech\Restrictcod\Model\restrictcod|\Magento\Framework\Object $row
     * @return string
     */
    public function getRowUrl($row)
    {
		
        return $this->getUrl(
            'restrictcod/*/edit',
            ['id' => $row->getId()]
        );
		
    }

	

}