<?php
 
namespace Eighteentech\Restrictcod\Block\Adminhtml\Restrictcod\Renderer;
 
use Magento\Framework\DataObject;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Payment\Model\Config;
 
class ProductAvailability extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
    /**
     * @var ScopeConfigInterface
     */
    protected $_appConfigScopeConfigInterface;

    /**
     * @var Config
     */
    protected $_paymentModelConfig;

    public function __construct(
        ScopeConfigInterface $appConfigScopeConfigInterface,
        Config $paymentModelConfig
    ) {
        $this->_appConfigScopeConfigInterface = $appConfigScopeConfigInterface;
        $this->_paymentModelConfig = $paymentModelConfig;
    }
 
    /**
     * get category name
     * @param  DataObject $row
     * @return string
     */
    public function render(DataObject $row)
    {
        $restrictedPaymentmethods = explode(',', $row->getRestrictedPaymentmethods());

        $payments = $this->_paymentModelConfig->getActiveMethods();
        $methods = [];
        foreach ($payments as $paymentCode => $paymentModel) {
            $paymentTitle = $this->_appConfigScopeConfigInterface
                ->getValue('payment/'.$paymentCode.'/title');
            $methods[] = $paymentCode;
        }
        
        $html = '';
        if(count(array_diff($methods, $restrictedPaymentmethods)) > 0) {
            $html.= '<span style="color:green; font-weight: bold;">Yes</span>';
        } else {
            $html.= '<span style="color:red; font-weight: bold;">No</span>';
        }

        return $html;
    }
}