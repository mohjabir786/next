<?php
 
namespace Eighteentech\Restrictcod\Block\Adminhtml\Restrictcod\Renderer;
 
use Magento\Framework\DataObject;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Payment\Model\Config;
 
class CodAvailability extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
    const XML_COD = 'cashondelivery';
 
    /**
     * get category name
     * @param  DataObject $row
     * @return string
     */
    public function render(DataObject $row)
    {
        $restrictedPaymentmethods = explode(',', $row->getRestrictedPaymentmethods());

        $html = '';
        if(!in_array(self::XML_COD, $restrictedPaymentmethods)) {
            $html.= '<span style="color:green; font-weight: bold;">Yes</span>';
        } else {
            $html.= '<span style="color:red; font-weight: bold;">No</span>';
        }

        return $html;
    }
}