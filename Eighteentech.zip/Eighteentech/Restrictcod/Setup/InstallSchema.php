<?php


namespace Eighteentech\Restrictcod\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

class InstallSchema implements InstallSchemaInterface
{

    /**
     * {@inheritdoc}
     */
    public function install(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $installer = $setup;
        $installer->startSetup();

        $eighteentech_restrictcod = $setup->getConnection()->newTable($setup->getTable('eighteentech_restrictcod'))
        ->addColumn(
            'id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            array('identity' => true,'nullable' => false,'primary' => true,'unsigned' => true,),
            'Entity ID'
        )
        ->addColumn(
            'zipcode',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            [],
            'zipcode'
        )
        ->addColumn(
            'estimated_days',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            [],
            'estimated_days'
        );
        

        $setup->getConnection()->createTable($eighteentech_restrictcod);

        $setup->endSetup();
    }
}
