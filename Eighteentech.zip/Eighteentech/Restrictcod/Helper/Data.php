<?php 

namespace Eighteentech\Restrictcod\Helper;

use Magento\Store\Model\Store;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	const XML_PATH_ACTIVE  = 'eighteentech_restrictcod/restrictcod/enabled';

	//const XML_PATH_DELIVERY_DAYS_MSG  = 'eighteentech_restrictcod/restrictcod/est_delivery_days';
	const XML_PATH_PRODUCT_AVAILABILITY_MSG  = 'eighteentech_restrictcod/restrictcod/product_avalibility_area';
	const XML_PATH_PRODUCT_NOT_AVAILABILITY_MSG  = 'eighteentech_restrictcod/restrictcod/product_not_avalibility_area';

	const XML_PATH_ERROR_MSG  = 'eighteentech_restrictcod/restrictcod/error_msg';

	const XML_PATH_SUCCESS_MSG  = 'eighteentech_restrictcod/restrictcod/success_msg';

	const XML_PATH_CUSTOMER_GROUPS  = 'eighteentech_restrictcod/restrictcod/customer_groups';

	protected $_customerSession;

    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Customer\Model\Session $customerSession
    ) 
    {
        $this->_customerSession = $customerSession; 
        parent::__construct($context);   
    }
	
	public function getEnabled($store = null){
		return $this->scopeConfig->getValue(self::XML_PATH_ACTIVE, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $store);
	}

	/*public function getDeliveryDaysMsg($store = null){
		return $this->scopeConfig->getValue(self::XML_PATH_DELIVERY_DAYS_MSG, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $store);
	}*/
	public function getAvailabliltyArea($store = null){
		return $this->scopeConfig->getValue(self::XML_PATH_PRODUCT_AVAILABILITY_MSG, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $store);
	}
	public function getNotAvailabliltyArea($store = null){
		return $this->scopeConfig->getValue(self::XML_PATH_PRODUCT_NOT_AVAILABILITY_MSG, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $store);
	}
	public function getErrorMsg($store = null){
		return $this->scopeConfig->getValue(self::XML_PATH_ERROR_MSG, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $store);
	}
	
	public function getSuccessMsg($store = null){
		return $this->scopeConfig->getValue(self::XML_PATH_SUCCESS_MSG, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $store);
	}

	public function getCustomerGroups($store = null){
		return $this->scopeConfig->getValue(self::XML_PATH_CUSTOMER_GROUPS, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $store);
	}

	public function checkCustomerGroup(){
		$customerGroups = [];
		$customerGroups = explode(',', $this->getCustomerGroups());
		if($this->_customerSession->isLoggedIn()){
			$groupId = $this->_customerSession->getCustomer()->getGroupId();
		}else{
			$groupId = 0;
		}
		if(in_array($groupId, $customerGroups)){
			return true;
		}
		return false;
	}
}
