<?php
namespace Eighteentech\Restrictcod\Plugin\Checkout\Model;

use Magento\Framework\Exception\StateException;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Payment\Model\Config;

class ShippingInformationManagement
{
    /**
     * @var \Magento\Quote\Model\QuoteRepository
     */
    protected $quoteRepository;

    /**
     * @var \Eighteentech\Restrictcod\Model\RestrictcodFactory
     */
    protected $restrictcodFactory;

    /**
     * @var ScopeConfigInterface
     */
    protected $_appConfigScopeConfigInterface;

    /**
     * @var Config
     */
    protected $_paymentModelConfig;
    
    public function __construct(
        \Magento\Quote\Model\QuoteRepository $quoteRepository,
        \Eighteentech\Restrictcod\Model\RestrictcodFactory $restrictcodFactory,
        ScopeConfigInterface $appConfigScopeConfigInterface,
        Config $paymentModelConfig
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->restrictcodFactory = $restrictcodFactory;
        $this->_appConfigScopeConfigInterface = $appConfigScopeConfigInterface;
        $this->_paymentModelConfig = $paymentModelConfig;
    }

    /**
     * @param \Magento\Checkout\Model\ShippingInformationManagement $subject
     * @param $cartId
     * @param \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
     */
    public function beforeSaveAddressInformation(
        \Magento\Checkout\Model\ShippingInformationManagement $subject,
        $cartId,
        \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
    ) {
        $address = $addressInformation->getShippingAddress();

        if (!$address->getPostcode()) {
            throw new StateException(__('Shipping address is not set'));
        } else {
            $_restrictcod = $this->restrictcodFactory->create()
                                 ->getCollection()
                                 ->addFieldToFilter('zipcode', ['eq' => $address->getPostcode()]);

            if ($_restrictcod->getSize()) {
                $restrictcod = $_restrictcod->getFirstItem();
                $RestrictedPaymentmethods = $restrictcod->getRestrictedPaymentmethods();

                $payments = $this->_paymentModelConfig->getActiveMethods();
                $methods = [];
                foreach ($payments as $paymentCode => $paymentModel) {
                    $paymentTitle = $this->_appConfigScopeConfigInterface
                        ->getValue('payment/'.$paymentCode.'/title');
                    $methods[] = $paymentCode;
                }
                
                if (count(array_diff($methods, explode(',', $RestrictedPaymentmethods))) == 0) {
                    throw new StateException(__('This product is not available in %1 postcode', $address->getPostcode()));
                }
            }
        }
    }
}