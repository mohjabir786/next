var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Eighteentech_Restrictcod/js/model/shipping-save-processor/default'
        }
    }
};
