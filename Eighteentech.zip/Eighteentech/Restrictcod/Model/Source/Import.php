<?php

namespace Eighteentech\Restrictcod\Model\Source;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;

class Import extends \Magento\Config\Model\Config\Backend\File
{
    protected $_restrictcodFactory;

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Config\ScopeConfigInterface $config,
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
        \Magento\MediaStorage\Model\File\UploaderFactory $uploaderFactory,
        \Magento\Config\Model\Config\Backend\File\RequestData\RequestDataInterface $requestData,
        Filesystem $filesystem,
        \Eighteentech\Restrictcod\Model\ResourceModel\RestrictcodFactory $restrictcodFactory,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->_restrictcodFactory = $restrictcodFactory;

        return parent::__construct(
            $context,
            $registry,
            $config,
            $cacheTypeList,
            $uploaderFactory,
            $requestData,
            $filesystem,
            $resource,
            $resourceCollection,
            $data
        );
    }

    public function beforeSave()
    {
        return $this;
    }

    public function save()
    {
        $value = $this->getValue();
        $tmpName = $this->_requestData->getTmpName($this->getPath());
        $directory = $this->_filesystem->getDirectoryRead(DirectoryList::SYS_TMP);      
        $file = $directory->openFile($directory->getRelativePath($tmpName), 'r');

        $zipcodes = [];
        $i=0;
        while (($csvLine = $file->readCsv()) !== false) {
            if ($i > 0) {
                // echo "<pre>"; print_r($csvLine); echo "</pre>";
                $zipcodes[$i]['zipcode'] = $csvLine[0];

                if ($csvLine[2] == 'yes') {
                    if(in_array('cashondelivery', explode(',', $csvLine[1]))) {
                        $zipcodes[$i]['restricted_paymentmethods'] = $csvLine[1];
                    } else {
                        $zipcodes[$i]['restricted_paymentmethods'] = implode(',', array_merge(explode(',', $csvLine[1]), ['cashondelivery']));
                    }
                } elseif($csvLine[2] == 'no') {
                    if(in_array('cashondelivery', explode(',', $csvLine[1]))) {
                        $zipcodes[$i]['restricted_paymentmethods'] = implode(',', array_diff(explode(',', $csvLine[1]), ['cashondelivery']));
                    } else {
                        $zipcodes[$i]['restricted_paymentmethods'] = $csvLine[1];
                    }
                } else {
                    $zipcodes[$i]['restricted_paymentmethods'] = $csvLine[1];
                }

                //$zipcodes[$i]['estimated_days'] = $csvLine[1];
            }
            $i++;
        }
        // echo "<pre>"; print_r($zipcodes); echo "</pre>";
        // die();
        $this->_restrictcodFactory->create()
            ->saveImportData($zipcodes);

    }


    protected function _getAllowedExtensions()
    {
        return ['csv', 'txt'];
    }
}
