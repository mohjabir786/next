<?php
namespace Eighteentech\Restrictcod\Model;

class Restrictcod extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Eighteentech\Restrictcod\Model\ResourceModel\Restrictcod');
    }
}
?>