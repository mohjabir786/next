<?php
namespace Eighteentech\Restrictcod\Model\ResourceModel;

class Restrictcod extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('eighteentech_restrictcod', 'id');
    }

    public function saveImportData($zipcodes)
    {
        if (!empty($zipcodes)) {
            foreach ($zipcodes as $zipcode) {
                $this->getConnection()->insertOnDuplicate($this->getMainTable(), $zipcode, ["zipcode","estimated_days"]);
            }
        }
    }
}
?>