<?php

namespace Eighteentech\Restrictcod\Model\ResourceModel\Restrictcod;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Eighteentech\Restrictcod\Model\Restrictcod', 'Eighteentech\Restrictcod\Model\ResourceModel\Restrictcod');
    }

}
?>