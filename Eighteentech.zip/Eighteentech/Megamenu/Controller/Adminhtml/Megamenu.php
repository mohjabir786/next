<?php


namespace Eighteentech\Megamenu\Controller\Adminhtml;

/**
 * Action Megamenu
 */
abstract class Megamenu extends \Magento\Backend\App\Action
{
    /**
     * @var \Eighteentech\Megamenu\Model\ResourceModel\Megamenu\CollectionFactory
     */
    protected $_collectionFactory;
    /**
     * @var \Magento\Config\Model\ResourceModel\Config
     */
    protected $_configResoure;
    /**
     * @var \Magento\Framework\App\Cache\TypeListInterface
     */
    protected $_typeListInterface;
    /**
     * @var \Magento\Framework\App\CacheInterface
     */
    protected $_cacheInterface;
    /**
     * @var \Eighteentech\Megamenu\Helper\Image
     */
    protected $_imageHelper;

    /**
     * Megamenu constructor.
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Eighteentech\Megamenu\Helper\Image $imageHelper
     * @param \Magento\Framework\App\CacheInterface $cacheInterface
     * @param \Magento\Framework\App\Cache\TypeListInterface $typeListInterface
     * @param \Magento\Config\Model\ResourceModel\Config $configResoure
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Eighteentech\Megamenu\Helper\Image $imageHelper,
        \Magento\Framework\App\CacheInterface $cacheInterface,
        \Magento\Framework\App\Cache\TypeListInterface $typeListInterface,
        \Magento\Config\Model\ResourceModel\Config $configResoure,
        \Eighteentech\Megamenu\Model\ResourceModel\Megamenu\CollectionFactory $collectionFactory
    ) {
        parent::__construct($context);
        $this->_imageHelper =$imageHelper;
        $this->_cacheInterface = $cacheInterface;
        $this->_typeListInterface = $typeListInterface;
        $this->_configResoure = $configResoure;
        $this->_collectionFactory = $collectionFactory;
    }

    
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Eighteentech_Megamenu::tech18megamenu');
    }
}
