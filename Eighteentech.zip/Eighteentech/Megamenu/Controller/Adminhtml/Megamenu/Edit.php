<?php


namespace Eighteentech\Megamenu\Controller\Adminhtml\Megamenu;

use Magento\Framework\Controller\ResultFactory;


class Edit extends \Eighteentech\Megamenu\Controller\Adminhtml\Megamenu
{
    
    public function execute()
    {
        $id = $this->getRequest()->getParam('megamenu_id');
        $model = $this->_objectManager->create('Eighteentech\Megamenu\Model\Megamenu');

        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This item no longer exists.'));
                $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

                return $resultRedirect->setPath('*/*/');
            }
        }

        $data = $this->_getSession()->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }

        $this->_objectManager->get('Magento\Framework\Registry')->register('megamenu_model', $model);

        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        if($id){
            $resultPage->getConfig()->getTitle()->prepend(__('Edit Mega Menu Item "%1"', $model->getNameMenu()));
        }else {
            $resultPage->getConfig()->getTitle()->prepend(__('New Mega Menu Item'));
        }
        $resultPage->setActiveMenu('Eighteentech_Megamenu::tech18megamenu');
        return $resultPage;
    }
}
