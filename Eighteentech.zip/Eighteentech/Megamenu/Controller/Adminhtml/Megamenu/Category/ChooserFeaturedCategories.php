<?php


namespace Eighteentech\Megamenu\Controller\Adminhtml\Megamenu\Category;

class ChooserFeaturedCategories extends \Eighteentech\Megamenu\Controller\Adminhtml\Megamenu
{
    
    public function execute()
    {
        $ids = $this->getRequest()->getParam('selected', []);
        if (is_array($ids)) {
            foreach ($ids as $key => &$id) {
                $id = (int)$id;
                if ($id <= 0) {
                    unset($ids[$key]);
                }
            }

            $ids = array_unique($ids);
        } else {
            $ids = [];
        }

        $block = $this->_view->getLayout()->createBlock(
            'Eighteentech\Megamenu\Block\Adminhtml\Megamenu\Category\Chooser\FeaturedCategories',
            'promo_widget_chooser_category_ids',
            ['js_form_object' => $this->getRequest()->getParam('form')]
        )->setCategoryIds(
            $ids
        );
        if ($block) {
            $this->getResponse()->setBody($block->toHtml());
        }
    }
}
