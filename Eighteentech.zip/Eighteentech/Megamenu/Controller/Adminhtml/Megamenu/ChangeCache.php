<?php


namespace Eighteentech\Megamenu\Controller\Adminhtml\Megamenu;


class ChangeCache  extends \Eighteentech\Megamenu\Controller\Adminhtml\Megamenu
{
    
    public function execute()
    {
        $status  = $this->getRequest()->getParam('status');
        try {
            $this->_typeListInterface->cleanType('config');
            $this->_typeListInterface->cleanType('block_html');
            if($status){
                $this->_configResoure->saveConfig('megamenu/general/cache','0','default', 0);
                $label = 'disabled';
            }else{
                $this->_configResoure->saveConfig('megamenu/general/cache','1','default', 0);
                $this->refreshMegamenuCache();
                $label = 'enabled';
            }
            $this->_typeListInterface->cleanType('config');
            $this->_typeListInterface->cleanType('block_html');
            $this->_typeListInterface->cleanType('full_page');
            $this->messageManager->addSuccess(
                __('Mega Menu Cache were %1', $label)
            );
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        $this->_redirect('*/*/index');
    }
    public function refreshMegamenuCache(){
        $collection = $this->_collectionFactory->create();
        try {
            foreach ($collection as $item) {
                $item->saveItem()->setConfigIds();
            }
            $this->_configResoure->saveConfig('megamenu/general/ids',implode(',',$collection->getAllids()),'default', 0);
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        return $this;
    }
}
