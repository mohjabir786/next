<?php


namespace Eighteentech\Megamenu\Controller\Adminhtml\Megamenu;

use Magento\Framework\Controller\ResultFactory;


class Delete extends \Eighteentech\Megamenu\Controller\Adminhtml\Megamenu
{
   
    public function execute()
    {
        $id = $this->getRequest()->getParam('megamenu_id');
        try {
            /** @var \{{model_name}} $model */
            $model = $this->_objectManager->create('Eighteentech\Megamenu\Model\Megamenu')->setId($id);
            $model->deleteItem()->delete();
            $this->messageManager->addSuccess(
                __('Delete successfully !')
            );
            $this->_typeListInterface->cleanType('block_html');
            $this->_typeListInterface->cleanType('full_page');
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

        return $resultRedirect->setPath('*/*/');
    }
}
