<?php


namespace Eighteentech\Megamenu\Controller\Adminhtml\Megamenu;


/**
 * Action ExportCsv
 */
class RebuildAll  extends \Eighteentech\Megamenu\Controller\Adminhtml\Megamenu
{
    /**
     * Execute action
     */
    public function execute()
    {
        $collection = $this->_collectionFactory->create();
        try {
            $this->_configResoure->saveConfig('megamenu/general/ids','0','default', 0);
            $this->_typeListInterface->cleanType('config');
            $this->_typeListInterface->cleanType('full_page');
            foreach ($collection as $item) {
                $item->saveItem()->setConfigIds();
            }
            $this->_configResoure->saveConfig('megamenu/general/ids',implode(',',$collection->getAllids()),'default', 0);
            $this->_typeListInterface->cleanType('config');
            $this->_typeListInterface->cleanType('full_page');
            $this->messageManager->addSuccess(__('The Mega Menu Cache has been refreshed.'));

        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        $this->_redirect('*/*/index');
    }
}
