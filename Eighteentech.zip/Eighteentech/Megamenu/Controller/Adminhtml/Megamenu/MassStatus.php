<?php


namespace Eighteentech\Megamenu\Controller\Adminhtml\Megamenu;

use Magento\Framework\Controller\ResultFactory;

/**
 * Action MassStatus
 */
class MassStatus extends \Eighteentech\Megamenu\Controller\Adminhtml\Megamenu
{
    /**
     * Execute action
     */
    public function execute()
    {
        $entityIds = $this->getRequest()->getParam('megamenus');
        $status = $this->getRequest()->getParam('status');

        if (!is_array($entityIds) || empty($entityIds)) {
            $this->messageManager->addError(__('Please select record(s).'));
        } else {
            /** @var \Eighteentech\Megamenu\Model\ResourceModel\Megamenu\Collection $collection */
            $collection = $this->_objectManager->create('Eighteentech\Megamenu\Model\ResourceModel\Megamenu\Collection');
            $collection->addFieldToFilter('megamenu_id', ['in' => $entityIds]);
            try {
                foreach ($collection as $item) {
                    $item->setStatus($status)
                        ->setIsMassupdate(true)
                        ->save();
                }
                $this->_typeListInterface->cleanType('config');
                $this->_typeListInterface->cleanType('block_html');
                $this->_typeListInterface->cleanType('full_page');
                $this->messageManager->addSuccess(
                    __('A total of %1 item(s) have been changed status.', count($entityIds))
                );
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }
        }
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);;

        return $resultRedirect->setPath('*/*/');
    }
}
