<?php


namespace Eighteentech\Megamenu\Controller\Adminhtml\Megamenu\Widget;

class ChooserFeatured extends \Eighteentech\Megamenu\Controller\Adminhtml\Megamenu
{
    /**
     * Prepare block for chooser
     *
     * @return void
     */
    public function execute()
    {

        $block = $this->_view->getLayout()->createBlock(
            'Eighteentech\Megamenu\Block\Adminhtml\Megamenu\Widget\Chooser\FeaturedProducts',
            'promo_widget_chooser_sku',
            ['data' => ['js_form_object' => $this->getRequest()->getParam('form')]]
        );
        if ($block) {
            $this->getResponse()->setBody($block->toHtml());
        }
    }
}
