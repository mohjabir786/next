<?php


namespace Eighteentech\Megamenu\Controller\Index;


class Index extends \Magento\Framework\App\Action\Action
{

    
    protected $_megamenuFactory;
    
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Eighteentech\Megamenu\Model\MegamenuFactory $megamenuFactory
    ) {
        $this->_megamenuFactory = $megamenuFactory;
        parent::__construct($context);
    }
    
    public function execute()
    {
        $items = $this->_megamenuFactory->create()->getCollection();
        $this->_typeListInterface->cleanType('block_html');
        $this->_typeListInterface->cleanType('full_page');
        foreach($items as $item) {
            $item->saveItem();
        }
        $this->_typeListInterface->cleanType('block_html');
        $this->_typeListInterface->cleanType('full_page');
        echo 'done!';
    }
}
