

var config = {
    map: {
       '*': {
       }
    },
    paths: {
    },
};