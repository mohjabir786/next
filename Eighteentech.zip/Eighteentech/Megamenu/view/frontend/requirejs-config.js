

var config = {
    map: {
       '*': {
           'megamenu' : 'Eighteentech_Megamenu/js/megamenu',
           'menu' : 'Eighteentech_Megamenu/js/menu',
       }
    },
    paths: {
    },
};