
var config = {
    map: {
       '*': {
       }
    },
    paths: {
    },
};