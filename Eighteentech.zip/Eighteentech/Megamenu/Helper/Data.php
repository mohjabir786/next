<?php


namespace Eighteentech\Megamenu\Helper;


class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
   
    protected $_scopeConfig;

    
    public function __construct(
        \Magento\Framework\App\Helper\Context $context
    ) {
        parent::__construct($context);
        $this->_scopeConfig = $context->getScopeConfig();
    }

    
    public function getMegamenutypeOptions() {
        return [
            [
                'label' => 'Top Menu',
                'value' => 0
            ],
            [
                'label' => 'Left Menu',
                'value' => 1
            ],

        ];
    }

    
    public function megamenuTypeToOptionArray() {
        $result = [];
        $array = $this->getMegamenutypeOptions();
        foreach ($array as $item) {
            $result[$item['value']] = $item['label'];
        }
        return $result;
    }
    /**
     * get menu type
     * @return menu type array
     */
    public function getMenutypeOptions() {
        return [
            [
                'label' => 'Anchor Text',
                'value' => \Eighteentech\Megamenu\Model\Megamenu::ANCHOR_TEXT
            ],
            [
                'label' => 'Default Category Listing',
                'value' => \Eighteentech\Megamenu\Model\Megamenu::CATEGORY_LEVEL
            ],
            [
                'label' => 'Static Category Listing',
                'value' => \Eighteentech\Megamenu\Model\Megamenu::CATEGORY_LISTING
            ],
            [
                'label' => 'Dynamic Category Listing',
                'value' => \Eighteentech\Megamenu\Model\Megamenu::CATEGORY_DYNAMIC
            ],
            [
                'label' => 'Products Listing',
                'value' => \Eighteentech\Megamenu\Model\Megamenu::PRODUCT_LISTING
            ],
            [
                'label' => 'Products Grid',
                'value' => \Eighteentech\Megamenu\Model\Megamenu::PRODUCT_GRID
            ],
            [
                'label' => 'Dynamic products listing by category',
                'value' => \Eighteentech\Megamenu\Model\Megamenu::PRODUCT_BY_CATEGORY_FILTER
            ],
            [
                'label' => 'Content',
                'value' => \Eighteentech\Megamenu\Model\Megamenu::CONTENT_ONLY
            ],
        ];
    }
    /**
     * get menu type options for grid menu item
     * @return menu type options
     */
    public function menuTypeToOptionArray() {
        $result = [];
        $array = $this->getMenutypeOptions();
        foreach ($array as $item) {
            $result[$item['value']] = $item['label'];
        }
        return $result;
    }
    
    public function getConfig($key, $store = null) {
        return $this->_scopeConfig->getValue(
             $key,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $store
        );
    }
}
