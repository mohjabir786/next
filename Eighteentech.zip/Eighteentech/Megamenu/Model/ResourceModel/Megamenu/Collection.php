<?php


namespace Eighteentech\Megamenu\Model\ResourceModel\Megamenu;


class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    
    protected function _construct()
    {
        $this->_init('Eighteentech\Megamenu\Model\Megamenu','Eighteentech\Megamenu\Model\ResourceModel\Megamenu');
    }
}
