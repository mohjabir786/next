<?php


namespace Eighteentech\Megamenu\Model\ResourceModel;


class Megamenu extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    const IMAGE_GALLERY_PATH = 'tech18/megamenu/images/megamenu/gallery';
    
    protected function _construct()
    {
        $this->_init('tech18_megamenu_megamenu','megamenu_id');
    }
}
