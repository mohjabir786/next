<?php


namespace Eighteentech\Megamenu\Model;

class Status
{
    const STATUS_ENABLED = 1;

    const STATUS_DISABLED = 2;

    public static function getAvailableStatuses()
    {
        return [
            self::STATUS_ENABLED => __('Enabled'),
            self::STATUS_DISABLED => __('Disabled')
        ];
    }

    public static function getSubmenualignOptions() {
        return [
            [
                'label' => 'From left menu',
                'value' => 0
            ],
            [
                'label' => 'From right menu',
                'value' => 1
            ],
            [
                'label' => 'From left item',
                'value' => 2
            ],
            [
                'label' => 'From right item',
                'value' => 3
            ],
        ];
    }

    public static function getMenutypeOptions() {
        return [
            [
                'label' => 'Anchor Text',
                'value' => self::ANCHOR_TEXT
            ],
            [
                'label' => 'Default Category Listing',
                'value' => self::CATEGORY_LEVEL
            ],
            [
                'label' => 'Static Category Listing',
                'value' => self::CATEGORY_LISTING
            ],
            [
                'label' => 'Dynamic Category Listing',
                'value' => self::CATEGORY_DYNAMIC
            ],
           [
                'label' => 'Product Listing',
                'value' => self::PRODUCT_LISTING
            ],
            [
                'label' => 'Product Grid',
                'value' => self::PRODUCT_GRID
            ],
           [
                'label' => 'Dynamic products listing by category',
                'value' => self::PRODUCT_BY_CATEGORY_FILTER
            ],
            [
                'label' => 'Content',
                'value' => self::CONTENT_ONLY
            ],
        ];
    }

}
