<?php


namespace Eighteentech\Megamenu\Model\System\Config;

class Effecttype
{
    const  Fade = 1;
    const  Slide = 2;
    const  Toggle = 3;
    public function toOptionArray(){
        return [
            [
                'value'=>self::Fade,
                'label'=>'Fade'
            ],
            [
                'value'=>self::Slide,
                'label'=>'Slide'
            ],
            [
                'value'=>self::Toggle,
                'label'=>'Toggle'
            ]
        ];
    }
}