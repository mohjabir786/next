<?php


namespace Eighteentech\Megamenu\Model\System\Config;

class MobileEffect

{
    //list effect type for fontend
    public function toOptionArray(){
        return [
            [
                'value'=>0,
                'label'=>'Slide'
            ],
            [
                'value'=>1,
                'label'=>'Blind'
            ],
        ];
    }
}