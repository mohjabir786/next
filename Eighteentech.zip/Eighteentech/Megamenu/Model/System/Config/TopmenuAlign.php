<?php


namespace Eighteentech\Megamenu\Model\System\Config;

class TopmenuAlign
{
    /**
     * @return array
     */
    public function toOptionArray(){
        return [
            [
                'value'=>0,
                'label'=>'Left'
            ],
            [
                'value'=>1,
                'label'=>'Right'
            ],
            [
                'value'=>2,
                'label'=>'Justify'
            ],
        ];
    }
}