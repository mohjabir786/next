<?php


namespace Eighteentech\Megamenu\Model\System\Config;

class TopmenuTransform
{
    //list effect type for fontend
    public function toOptionArray(){
        return [
            [
                'value'=>'none',
                'label'=>'Normal'
            ],
            [
                'value'=>'uppercase',
                'label'=>'Uppercase'
            ],
            [
                'value'=>'lowercase',
                'label'=>'Lowercase'
            ],
            [
                'value'=>'capitalize',
                'label'=>'Capitalize'
            ],
        ];
    }
}