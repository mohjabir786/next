<?php


namespace Eighteentech\Megamenu\Block\Adminhtml\Megamenu\Edit;

/**
 * Tabs containerTabs
 */
class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    
    protected function _construct()
    {
        parent::_construct();
        $this->setId('general_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Megamenu Information'));
    }
    
    protected function _prepareLayout()
    {
        parent::_prepareLayout();

        return $this;
    }
}
