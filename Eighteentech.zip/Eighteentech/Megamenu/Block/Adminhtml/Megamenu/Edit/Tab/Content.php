<?php


namespace Eighteentech\Megamenu\Block\Adminhtml\Megamenu\Edit\Tab;

use Magento\Backend\Block\Widget\Tab\TabInterface;


class Content extends \Magento\Backend\Block\Widget\Form\Generic implements TabInterface
{
    
    protected $_adminSession;
    
    protected $_template = 'Eighteentech_Megamenu::content.phtml';

    
    protected $_systemStore;
    
    protected  $_storeManager;

    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Magento\Backend\Model\Auth\Session $adminSession,
        array $data = array()
    ) {
        parent::__construct($context, $registry, $formFactory, $data);
        $this->_storeManager= $context->getStoreManager();
        $this->_systemStore =$systemStore;
        $this->_adminSession= $adminSession;
    }


    
    public function getTabLabel()
    {
        return __('Content information');
    }

    
    public function getTabTitle()
    {
        return __('Content information');
    }

    
    public function canShowTab()
    {
        return true;
    }

    
    public function isHidden()
    {
        return false;
    }

    
    protected function _prepareLayout()
    {
        
        $headerfooter= $this->getLayout()->createBlock('Eighteentech\Megamenu\Block\Adminhtml\Megamenu\Edit\Tab\Content\Headerfooter');
        $this->setChild('header_and_footer', $headerfooter);
        
        $maincontent= $this->getLayout()->createBlock('Eighteentech\Megamenu\Block\Adminhtml\Megamenu\Edit\Tab\Content\Maincontent');
        $maincontent->setData(
           [
                'label' => __('Main Content'),
                'onclick' => 'templateControl.load();',
                'type' => 'button',
                'class' => 'save'
            ]
        );
        $this->setChild('main_content', $maincontent);
        
        $featureditem= $this->getLayout()->createBlock('Eighteentech\Megamenu\Block\Adminhtml\Megamenu\Edit\Tab\Content\Featureditem');
        $featureditem->setData(
           [
                'label' => __('Featured Item'),
                'onclick' => 'templateControl.load();',
                'type' => 'button',
                'class' => 'save'
            ]
        );
        $this->setChild('featured_item', $featureditem);




        return parent::_prepareLayout();
    }
    public function getLoadButtonHtml() {
        return $this->getChildHtml('load_button');
    }

    public function getLoadUrl() {
        return $this->getUrl('*/*/gettemplate');
    }

    public function getSaveUrl() {
        return $this->getUrl('*/*/save');
    }

    public function getFormData() {
        if ($this->_adminSession->getMegamenuData()) {
            $data = $this->_adminSession->getMegamenuData();
            $this->_adminSession->setMegamenuData(null);
        } elseif ($this->_coreRegistry->registry('megamenu_data'))
            $data = $this->_coreRegistry->registry('megamenu_data')->getData();
        if(isset($data) && $data){
            return $data;
        }
        return null;
    }


}
