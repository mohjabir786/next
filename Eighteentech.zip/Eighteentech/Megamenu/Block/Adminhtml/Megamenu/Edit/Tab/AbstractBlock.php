<?php


namespace Eighteentech\Megamenu\Block\Adminhtml\Megamenu\Edit\Tab;

class AbstractBlock extends \Magento\Backend\Block\Widget\Form\Generic
{
    
    protected $_storeManager;
    
    protected $_objectManager;
    
    protected $_wysiwygConfig;
    
    protected $_megaModel;
    
    protected $_adminSession;

    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Backend\Model\Auth\Session $adminSession,
        \Eighteentech\Megamenu\Model\Megamenu $megaModel,
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        array $data = []
    ) {
        parent::__construct($context, $registry, $formFactory, $data);
        $this->_adminSession= $adminSession;
        $this->_megaModel =$megaModel;
        $this->_wysiwygConfig =$wysiwygConfig;
        $this->_objectManager =$objectManager;
        $this->_storeManager= $context->getStoreManager();
    }
    
    public function getRegistryModel()
    {
        return $this->_coreRegistry->registry('megamenu_model');
    }

    public function getCatalogCategoryColection(){
        return $this->_objectManager->create('Magento\Catalog\Model\ResourceModel\Category\Collection');
    }

    public function getRuleTrigerImage(){
        return   $this->_storeManager->getStore()->getBaseUrl().'pub/static/adminhtml/Magento/backend/en_US/images/rule_chooser_trigger.gif';
    }
}