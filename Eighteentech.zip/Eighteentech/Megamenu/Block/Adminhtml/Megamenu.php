<?php


namespace Eighteentech\Megamenu\Block\Adminhtml;


class Megamenu extends \Magento\Backend\Block\Widget\Grid\Container
{
    const STATUS_ENABLED = 1;


    
    protected $_dataHelper;
    
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Eighteentech\Megamenu\Helper\Data $dataHelper,
        array $data = []
    )
    {
        $this->_dataHelper = $dataHelper;
        parent::__construct($context, $data);
    }

    
    public function getCache()
    {
        return $this->_dataHelper->getConfig('megamenu/general/cache',$store=null);
    }

    
    protected function _construct()
    {
        $this->_controller = 'adminhtml_megamenu';
        $this->_blockGroup = 'Eighteentech_Megamenu';
        $this->_headerText = __('Megamenu grid');
        $this->_addButtonLabel = __('Add New Megamenu');
        $cache = $this->getCache();
        if($cache == self::STATUS_ENABLED){
            $label = 'Disable Cache';
            $text = '<h3 style="margin:0;">Mega Menu Cache Status: <span style="background:#3CB861;padding: 3px 15px;color: #fff;font-size: 11px;border-radius: 7px;">ENABLED</span></h3>';
        }else{
            $label = 'Enable Cache';
            $text = '<h3 style="margin:0;">Mega Menu Cache Status: <span style="background:#E41101;padding: 3px 15px;color: #fff;font-size: 11px;border-radius: 7px;">DISABLED</span></h3>';
        }
        /**
         * add disable button
         */

        $this->addButton(
            $label,
            [
                'label' => $label,
                'onclick'   => 'setLocation(\'' . $this->getUrl('megamenuadmin/megamenu/changeCache',['status'=>$cache]) .'\')',
                'class' => 'action-default scalable add primary'
            ],$level = 0, $sortOrder = 1
        );
        /**
         * add refresh button
         */
        $this->addButton(
            'Refresh Menu Cache',
            [
                'label' => 'Refresh Menu Cache',
                'onclick' => 'setLocation(\'' . $this->getUrl('megamenuadmin/megamenu/rebuildAll') . '\')',
                'class' => 'action-default scalable add primary'
            ],$level = 0, $sortOrder = 2
        );
        $this->addButton(
            'Status',
            [
                'label' => $text,
                'title' => 'Status',
                'onclick'   => '',
                'class' => ''
            ],$level = 0, $sortOrder = 0
        );

        parent::_construct();
    }
    protected function _addNewButton()
    {
        $this->addButton(
            'add',
            [
                'label' => $this->getAddButtonLabel(),
                'onclick' => 'setLocation(\'' . $this->getCreateUrl() . '\')',
                'class' => 'add primary'
            ],$level = 0, $sortOrder = 3
        );
    }


}
