<?php



namespace Eighteentech\Megamenu\Block\Adminhtml\System;

class AddJs extends \Magento\Config\Block\System\Config\Form\Fieldset
{

    /**
     * @param \Magento\Framework\Data\Form\Element\AbstractElement $element
     *
     * @return string
     */
    public function render(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $script = '
        <script>
            require(["Eighteentech_Megamenu/js/jscolor.min"],function($){});
        </script>
        ';

        return $script;
    }
}