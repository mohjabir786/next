<?php


namespace Eighteentech\Megamenu\Observer;

class Cssgen implements \Magento\Framework\Event\ObserverInterface
{
    
    protected $_directoryList;
    
    protected $_blockFactory;
    
    protected $_genFile;
    
    protected $_websiteFactory;
    
    protected $_storeFactory;
    
    protected $_storeManager;
    protected $_appRequest;
    
    public function __construct(
        \Magento\Framework\App\RequestInterface $requestInterface,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Store\Model\StoreFactory $storeFactory,
        \Magento\Store\Model\WebsiteFactory $websiteFactory,
        \Magento\Framework\Filesystem\Io\File  $genFile,
        \Magento\Framework\View\Element\BlockFactory $blockFactory,
        \Magento\Framework\Filesystem\DirectoryList $directoryList

    ) {
        $this->_appRequest = $requestInterface;
        $this->_storeManager = $storeManager;
        $this->_storeFactory = $storeFactory;
        $this->_websiteFactory = $websiteFactory;
        $this->_genFile = $genFile;
        $this->_blockFactory= $blockFactory;
        $this->_directoryList =$directoryList;
    }

    
    public function getBaseDirUrl()
    {
        return $this->_directoryList->getRoot();
    }

    
    public function getGenFile(){
        return $this->_genFile;
    }
    
    public function execute(\Magento\Framework\Event\Observer $observer)
    {   /*
        $storeCode = 0;
        $websiteCode = 0;
        if($observer->getStore()){
            $store = $this->_storeFactory->create()->load($observer->getStore());
            $website = $this->_websiteFactory->create()->load($store->getWebsiteId());
            $storeCode = $store->getCode();
            $websiteCode = $website->getCode();
        }elseif($observer->getWebsite()){
            $website = $this->_websiteFactory->create()->load($observer->getWebsite());
            $websiteCode = $website->getCode();
        }
        $path = 'css/config/custom/';
        $storeId = null;
        if($storeCode && $websiteCode){
            $storeId = $this->_storeFactory->create()->load($storeCode, 'code')->getId();
            $filename = 'custom_'.$websiteCode.'_'.$storeCode.'.css';

        }elseif(!$storeCode && $websiteCode){
            $storeId = $this->_websiteFactory->create()->load($websiteCode,'code')->getDefaultGroup()->getDefaultStoreId();
            $filename = 'custom_'.$websiteCode.'_default.css';
        }else{
            $filename = 'default.css';
            $path = 'css/config/';
        }
        $file = $this->getBaseDirUrl().'/app/code/Eighteentech/Megamenu/view/frontend/web/'.$path.$filename;
        $css = $this->_blockFactory->createBlock('Eighteentech\Megamenu\Block\Megamenu')->setArea('frontend')->setBilly($storeId)->setTemplate('Eighteentech_Megamenu::cssgen.phtml')->toHtml();
        $this->getGenFile()->setAllowCreateFolders(true);
        $this->getGenFile()->open([ 'path' => $path ]);
        $this->getGenFile()->write($file, $css, 0777);
        $this->getGenFile()->streamLock(true);
        $this->getGenFile()->streamWrite($css);
        $this->getGenFile()->streamUnlock();
        $this->getGenFile()->streamClose();
   */
    }
}
