<?php

namespace Eighteentech\Bestseller\Ui\Component\Listing\Column;

class Category extends \Magento\Ui\Component\Listing\Columns\Column {

    protected $_categoryFactory;

    public function __construct(
        \Magento\Framework\View\Element\UiComponent\ContextInterface $context,
        \Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        array $components = [],
        array $data = []
    ){
        $this->_categoryFactory = $categoryFactory;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource) {
        if (isset($dataSource['data']['items'])) {

            foreach ($dataSource['data']['items'] as & $item) {

                //$item['yourcolumn'] is column name
                $item['category'] = $this->getCategoryLabel($item['category']); //Here you can do anything with actual data

            }
        }

        return $dataSource;
    }


    protected function getCategoryLabel($catId){

        $categoryLabel = '';
        $category = $this->_categoryFactory->create();
        $category->load($catId);
        $categoryName = $category->getName();
        $categoryPath = explode('/',$category->getPath());
        $categories = array_slice($categoryPath, 1, -1);
        foreach ($categories as $cat) {
            $categoryLabel .= $this->getCategoryTitle($cat).'/';
        }
        return $categoryLabel.''.$categoryName;
    }


    public function getCategoryTitle($categoryId){
        $category = null;
        $category = $this->_categoryFactory->create();
        $category->load($categoryId);        
        return $category->getName();
    }
}