<?php

namespace Eighteentech\Bestseller\Block\Category;

use Magento\Framework\View\Element\AbstractBlock;
use Magento\Framework\Registry;

class ProductList extends \Magento\Catalog\Block\Product\AbstractProduct
{
protected $_itemCollection;
protected $_productCollectionFactory;
protected $_categoryFactory;
protected $_bestsellerCollectionFactory;

public function __construct(
        \Magento\Catalog\Block\Product\Context $context,       
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,        
        \Eighteentech\Bestseller\Model\ResourceModel\Bestseller\CollectionFactory $bestsellerCollectionFactory,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        Registry $registry,      
        array $data = []
    ) {
        
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->_bestsellerCollectionFactory = $bestsellerCollectionFactory;
        $this->_categoryFactory = $categoryFactory;
        $this->registry = $registry;
        parent::__construct(
            $context,
            $data
        );
    }   
    
     

    /**
     * Get collection items
     *
     * @return Collection
     */
    public function getItems()
    {
        $pds = $this->getBestSellerItems();
        if($pds){            
            //$bestSellerSkus = ['MH01','MH03','MH06','MJ01','MJ03','MJ05','MJ08', 'MJ09', 'MJ011'];
            $collection = $this->_productCollectionFactory->create();
            $collection->addAttributeToSelect('*');
            return $collection->addAttributeToFilter('entity_id', array('in' => $pds));
        }
        
        return false;
    }
    
    protected function getCurrentCategory(){
		
		return $this->registry->registry('current_category');
	}
    
    
    /*public function getCategoryBestSellers()
    {
        $currentCategory = $this->getCurrentCategory();
        $category = $this->_categoryFactory->create()->load($currentCategory->getId());
        $categoryName = $category->getName();
        return $categoryName;
    }*/
    
    public function canItemsAddToCart()
    {
        foreach ($this->getItems() as $item) {
            if (!$item->isComposite() && $item->isSaleable() && !$item->getRequiredOptions()) {
                return true;
            }
        }
        return false;
    }


    public function getBestSellerItems(){
        $currentCategory = $this->getCurrentCategory();
        //echo $currentCategory->getId();
        if(is_object($currentCategory)){            
            $collection = $this->_bestsellerCollectionFactory->create();
            //$collection->addAttributeToSelect('*');
            $bestsellerCollection = $collection->addFieldToFilter('category', array('eq' => $currentCategory->getId()));
            if(is_object($bestsellerCollection)){
                
                 $bestseller = $bestsellerCollection->getFirstItem();
                 return $bestseller->getProducts($bestseller);
                 //return $bestseller->getData();
             }else
             return false;
        }else
          return false;

    }
}
