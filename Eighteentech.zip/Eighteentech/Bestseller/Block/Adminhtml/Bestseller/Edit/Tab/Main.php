<?php
namespace Eighteentech\Bestseller\Block\Adminhtml\Bestseller\Edit\Tab;

class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $store;

    /**
    * @var \Eighteentech\Bestseller\Helper\Data $helper
    */
    protected $helper;


    protected $_categoryCollectionFactory;

    protected $_categoryFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Eighteentech\Bestseller\Helper\Data $helper,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        array $data = []
    ) {
        $this->helper = $helper;
        $this->_categoryCollectionFactory = $categoryCollectionFactory;
        $this->_categoryFactory = $categoryFactory;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        /* @var $model \Eighteentech\Bestseller\Model\Bestseller */
        $model = $this->_coreRegistry->registry('et_bestseller');

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('bestseller_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Best Seller Information')]);

        if ($model->getId()) {
            $fieldset->addField('bestseller_id', 'hidden', ['name' => 'bestseller_id']);
        }

        $fieldset->addField(
            'category',
            'select',
            [
                'name' => 'category',
                'label' => __('Cateogry'),
                'title' => __('Cateogry'),
                'required' => true,
                'values' => $this->getCategoryList()
            ]
        );        

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Main');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Main');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return true; //$this->_authorization->isAllowed($resourceId);
    }


    protected function getCategoryList(){
        $categoryList = array();

        $categoryCollection =  $this->_categoryCollectionFactory->create();
        $categoryCollection->addAttributeToSelect('*');
        $categoryCollection->addIsActiveFilter();
        
        $categoryList[] =['label'=>'Select Category','value'=>'0'];

        foreach($categoryCollection as $category){
            if($category->getId()!=2){
                $categoryLabel = $this->getCategoryLabel($category);
                $categoryList[] =['label'=>$categoryLabel,'value'=>$category->getId()];
            }
            
        }

        return $categoryList;

    }


    protected function getCategoryLabel($category){

        $categoryLabel = '';
        $categoryName = $category->getName();
        $categoryPath = explode('/',$category->getPath());
        $categories = array_slice($categoryPath, 1, -1);
        foreach ($categories as $cat) {
            $categoryLabel .= $this->getCategoryTitle($cat).'/';
        }
        return $categoryLabel.''.$categoryName;
    }


    public function getCategoryTitle($categoryId){
        $category = null;
        $category = $this->_categoryFactory->create();
        $category->load($categoryId);        
        return $category->getName();
    }
}
