var config = {
    map: {
        '*' : {
            'owlcarousel' : 'Eighteentech_Bestseller/js/owl.carousel',
            'owlcarouselmin' : 'Eighteentech_Bestseller/js/owl.carousel.min'
        }
    },    
    shim: {
        'Eighteentech_Bestseller/js/owl.carousel': {
            deps: ['jquery']
        },
        'Eighteentech_Bestseller/js/owl.carousel.min': {
            deps: ['jquery']
        }
    }
};
