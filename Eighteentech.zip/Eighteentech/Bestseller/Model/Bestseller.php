<?php

namespace Eighteentech\Bestseller\Model;

use Magento\Framework\DataObject\IdentityInterface;

class Bestseller extends \Magento\Framework\Model\AbstractModel implements IdentityInterface
{

    /**
     * CMS page cache tag
     */
    const CACHE_TAG = 'et_products_grid';

    /**
     * @var string
     */
    protected $_cacheTag = 'et_products_grid';

    /**
     * Prefix of model events names
     *
     * @var string
     */
    protected $_eventPrefix = 'et_products_grid';

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Eighteentech\Bestseller\Model\ResourceModel\Bestseller');
    }

    /**
     * Return unique ID(s) for each object in system
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getProducts(\Eighteentech\Bestseller\Model\Bestseller $object)
    {
        $tbl = $this->getResource()->getTable(\Eighteentech\Bestseller\Model\ResourceModel\Bestseller::TBL_ATT_PRODUCT);
        $select = $this->getResource()->getConnection()->select()->from(
            $tbl,
            ['product_id']
        )
        ->where(
            'bestseller_id = ?',
            (int)$object->getId()
        );
        return $this->getResource()->getConnection()->fetchCol($select);
    }
}
