<?php
namespace Eighteentech\Bestseller\Model\ResourceModel\Bestseller;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'bestseller_id';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Eighteentech\Bestseller\Model\Bestseller', 'Eighteentech\Bestseller\Model\ResourceModel\Bestseller');
    }
}
